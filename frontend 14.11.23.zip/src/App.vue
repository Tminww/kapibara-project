<template>
    <v-app>
        <v-app-bar :elevation="2" />
        <v-container class="main-container">
            <v-row>
                <v-col>
                    <select-region :regions="regions" />
                </v-col>
            </v-row>
            <v-row>
                <v-col>
                    <h2>Statistics from Subjects ({{ getDocumentCount }})</h2>
                </v-col>
            </v-row>

            <!-- <v-row align="center" justify="center">
                <v-col v-for="(variant, i) in variants" :key="i" cols="auto">
                    <v-card class="mx-auto" max-width="344" :color="color" :variant="variant">
                        <v-card-item>
                            <div>
                                <div class="text-overline mb-1">
                                    {{ variant }}
                                </div>
                                <div class="text-h6 mb-1">
                                    Headline
                                </div>
                                <div class="text-caption">Greyhound divisely hello coldly fonwderfully</div>
                            </div>
                        </v-card-item>

                        <v-card-actions>
                            <v-btn>
                                Button
                            </v-btn>
                        </v-card-actions>
                    </v-card>
                </v-col>
            </v-row> -->

            <v-row>
                <v-col v-if="error">
                    {{ error }}
                </v-col>
                <template v-else>
                    <v-col v-if="loading">Loading...</v-col>
                    <template v-else>
                        <v-col v-for="stat in statistics.regions">
                            <stat-row :key="stat.region_name" :stat="stat" />
                        </v-col>
                    </template>
                </template>
            </v-row>
            <div></div>
        </v-container>
    </v-app>
</template>

<script lang="js">

// import { ref } from 'vue'

// const variants = ['elevated', 'flat', 'tonal', 'outlined']
// const color = ref('indigo')

import { getAllStatistics, getAllRegions } from "./api/statistics.js";
import { SelectRegion, StatRow } from "@/components/widget";

export default {
    name: "app",
    components: { StatRow, SelectRegion },

    data() {
        return {
            statistics: [],
            regions: [],
            loading: false,
            error: null
        };
    },
    computed: {
        /* if data is not updated value bring in cash*/
        getDocumentCount() {
            return this.statistics.count;
        }
    },

    methods: {
        async loadStatistics() {
            try {
                this.error = null;
                this.loading = true;
                this.statistics = await getAllStatistics();
            } catch (e) {
                this.error = e.message;
                this.statistics = [];
            } finally {
                this.loading = false;
            }
        },

        async loadRegions() {
            this.regions = await getAllRegions();
        }
    },

    async mounted() {
        this.loadRegions();
        console.log();
        this.loadStatistics();
    }
};
</script>

<style scoped>
.main-container {
    margin-top: 100px;
}
</style>

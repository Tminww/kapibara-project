<template>
    <v-card width="400" :title="stat.region_name" :subtitle="stat.count">
        <v-card-text>
            <div class="npa-statistics" v-for="region in stat.stat">
                <div class="npa-name">{{ region.name }}:</div>
                <div class="npa-count">{{ region.count }}</div>
            </div>
        </v-card-text>
    </v-card>
</template>
<script>
export default {
    name: "stat-row",
    props: {
        stat: { type: Object, required: true }
    }
};
</script>
<style scoped>
.row {
    display: flex;
    margin-bottom: 5px;
    border: 1px solid gray;
    border-radius: 15px;
    justify-content: flex-start;
}

.title {
    margin-bottom: 5px;
    margin-top: 5px;
    margin-left: 10px;
    padding-left: 10px;
    padding-right: 10px;
    border-right: 1px solid gray;
    margin-right: 20px;
    flex-basis: 100px;
}
.npa-statistics {
    margin-bottom: 5px;
    align-items: center;
    /*border: 1px solid gold;*/

    display: flex;
}
.statistics {
    /*border: 1px solid green;*/
    margin-bottom: 5px;
    margin-top: 5px;
}

.region-count-document {
    /*border: 1px solid blue;*/
}

.region-name {
    font-weight: 700;
    /*border: 1px solid red;*/
}
.npa-name {
    font-weight: 700;
    margin-right: 5px;
}
.npa-count {
}
</style>

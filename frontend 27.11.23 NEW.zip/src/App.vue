<template>
    <v-app>
        <v-row>
            <v-col>
                <v-container>
                    <v-app-bar scroll-behavior="collapse" color="primary" prominent>

                        <v-toolbar-title>TEST</v-toolbar-title>

                        <v-btn variant="text" icon="mdi-magnify"></v-btn>

                        <v-btn variant="text" icon="mdi-filter"></v-btn>

                        <v-btn variant="text" icon="mdi-dots-vertical"></v-btn>
                    </v-app-bar>

                </v-container>
            </v-col>

        </v-row>



        <v-row>
            <v-col cols="3">
                <v-container>
                    <request-form :districts="getRegionsToRequest" />
                </v-container>
            </v-col>

            <v-col>

                <v-container>
                    <v-row>
                        <v-col v-if="error">
                            {{ error }}
                        </v-col>
                        <template v-else>
                            <!-- НЕ РАБОТАЕТ ЗАГРУЗКА -->
                            <v-col v-if="!loaded" class="d-flex align-center justify-center">
                                <v-progress-circular indeterminate />
                            </v-col>
                            <template v-else>


                                <v-col>
                                    <stat-all-card :all="this.getAllStatistics" />
                                </v-col>

                                <v-col v-for="district in this.getDistricts">
                                    <stat-district-card :district="district" />
                                </v-col>

                            </template>
                        </template>
                    </v-row>
                </v-container>
            </v-col>
        </v-row>




    </v-app>
</template>

<script lang="js">
import { mapGetters, mapActions } from 'vuex'
import { StatDistrictCard } from './components/widget';
export default {
    name: 'app',
    components: { StatDistrictCard, RequestForm, StatAllCard },

    data() {
        return {
            loaded: false,
            error: null,


        }
    },
    computed: {
        ...mapGetters(['getStatistics', 'getRegionsToRequest', 'getRegionsInDistrict', 'getDistricts', 'getAllStatistics']),
    },

    methods: {
        ...mapActions(['dropStatistics', 'dropRegionsToRequest', 'loadRegions', 'loadStatistics']),
        async loadStatisticsStore() {
            try {
                this.loaded = false;
                this.error = null
                this.loadStatistics()
            } catch (e) {
                this.error = e.message
                this.dropStatistics()
            } finally {
                this.loaded = true;
            }
        },

        async loadRegionsStore() {
            try {
                this.loaded = false;
                this.error = null
                this.loadRegions()
            } catch (e) {
                this.error = e.message
                this.dropRegionsToRequest()
            } finally {
                this.loaded = true;
            }

            // this.regionsToRequest = await getAllRegions()
        },
    },

    async mounted() {
        await this.loadRegionsStore()
        await this.loadStatisticsStore()
        console.log("getStat", this.getStatistics)

    },

    watch: {
        group() {
            this.drawer = false
        },
    },
}
</script>

<style scoped>
.main-container {
    margin-top: 100px;
}
</style>

import { createStore } from 'vuex'
import { getAllStatistics, getAllRegions } from '../api/statistics.js'

const store = createStore({
    state() {
        return {
            statistics: [],
            regionsToRequest: [],
            regionsFromDistrict: [],
        }
    },
    getters: {
        getRegionsInDistrict(state, districtId) {
            return state.statistics.districts[districtId]
        },

        getAllStatistics(state) {
            return {
                name: state.statistics.name,
                count: state.statistics.count,
                stat: state.statistics.state,
            }
        },

        getDistricts(state) {
            return state.statistics.districts
        },

        getStatistics(state) {
            return state.statistics
        },
        getRegionsToRequest(state) {
            return state.regionsToRequest
        },
    },
    mutations: {
        setStatistics(state, newValue) {
            // if (Array.isArray(newValue)) {
            //     state.statistics = newValue
            // }
            state.statistics = newValue
        },

        setRegionsToRequest(state, newValue) {
            // if (Array.isArray(newValue)) {
            //     state.statistics = newValue
            // }
            state.regionsToRequest = newValue
        },
    },
    actions: {
        setStatistics(context, newValue) {
            context.commit('setStatistics', newValue)
        },
        setRegionsToRequest(context, newValue) {
            context.commit('setRegionsToRequest', newValue)
        },

        dropStatistics(context) {
            context.commit('setStatistics', [])
        },
        dropRegionsToRequest(context) {
            context.commit('setRegionsToRequest', [])
        },
        async loadStatistics(context) {
            const statistics = await getAllStatistics()
            context.commit('setStatistics', statistics)
            console.log(statistics)
        },
        async loadRegions(context) {
            const regionsToRequest = await getAllRegions()
            context.commit('setRegionsToRequest', regionsToRequest)
            console.log(regionsToRequest)
        },
    },
})

export default store

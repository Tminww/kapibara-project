<template>
    <v-card class="rounded-xl mx-auto" elevation="0" variant="outlined" width="400">
        <v-card-title class="text-h6 mb-1">
            {{ name }}
        </v-card-title>

        <v-card-subtitle class="text-subtitle-2">
            {{ count }}
        </v-card-subtitle>

        <v-card-text>
            <doughnut-chart v-if="loaded" :chart-data="this.chartData" :chart-options="this.chartOptions" />
        </v-card-text>

        <v-card-actions>
            <v-btn color="indigo">
                Открыть статистику
            </v-btn>
        </v-card-actions>


    </v-card>
</template>

<script lang="js">
import DoughnutChart from './DoughnutChart.vue'
export default {
    name: 'stat-district-card',

    components: { DoughnutChart },
    props: {

        district: { type: Object, required: true },
    },
    data() {
        return {
            loaded: false,
            name: this.district.name,
            count: this.district.count,
            stat: this.district.stat,
            chartData: {
                labels: [],
                datasets: [
                    {

                        backgroundColor: [
                            'rgb(255, 99, 132)',
                            'rgb(54, 162, 235)',
                            'rgb(255, 205, 86)',
                            'rgb(255, 99, 132)',
                            'rgb(54, 99, 235)',
                            'rgb(255, 99, 86)',
                            'rgb(255, 99, 99)',
                            'rgb(54, 162, 99)',
                            'rgb(255, 205, 99)',
                        ],

                        data: []
                    }
                ]
            },
            chartOptions: {
                responsive: true,
                plugins: {
                    legend: {
                        // Uncomment to show legend
                        position: 'bottom',
                    },
                    title: {
                        display: true,

                    }
                }

            }
        }
    },
    methods: {
        setup() {
            let labels = [];
            let data = [];
            for (const row of this.stat) {
                labels.push(row.name);
                data.push(row.count);
            }
            this.chartData.labels = labels;
            this.chartData.datasets[0].data = data;
            console.log(this.chartData)
        }
    },
    async mounted() {
        this.loaded = false
        this.setup()
        this.loaded = true

    }


}
</script>
<style scoped></style>

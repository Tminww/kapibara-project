<template>
    <div v-for="district in districts">
        <v-select :model-modifiers="selectedRegions" chips :label="district.name" :items="getRegionsName(district)" multiple
            variant="outlined"></v-select>
    </div>
</template>

<script lang="js">
export default {
    name: 'request-form',
    props: {
        districts: { type: Object, required: true },
    },
    data() {
        return {
            selectedRegions: [],

        }
    },
    methods: {
        getRegionsName(district) {
            let regionsName = [];
            for (const region of district.regions) {
                regionsName.push(region.name);
            }
            console.log(regionsName);
            return regionsName
        }
    },
}
</script>

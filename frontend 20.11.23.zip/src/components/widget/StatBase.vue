<template>
    <div class="npa-statistics" v-for="stat in stat">
        <div class="npa-name">{{ stat.name }}:</div>
        <div class="npa-count">{{ stat.count }}</div>
    </div>
</template>

<script>
export default {
    name: "stat-base",
    props: {
        stat: { type: Array, required: true },

    },

}
</script>

<style scoped>
.npa-statistics {
    margin-bottom: 5px;
    align-items: center;
    /*border: 1px solid gold;*/

    display: flex;
}

.npa-name {
    font-weight: 700;
    margin-right: 5px;
}

.npa-count {
    margin-right: 5px;
}
</style>
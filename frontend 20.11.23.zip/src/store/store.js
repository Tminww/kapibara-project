import { createStore } from 'vuex'
import { getAllStatistics, getAllRegions } from '../api/statistics.js'

const store = createStore({
    state() {
        const initial = []
        return {
            statistics: initial,
            regionsToRequest: initial,
            regionsFromDistrict: initial,
        }
    },
    getters: {
        regionsFromDistrict(state) {
            return state.regionsFromDistrict
        },
        statistics(state) {
            return state.statistics
        },
        regionsToRequest(state) {
            return state.regionsToRequest
        },
    },
    mutations: {
        setStatistics(state, newValue) {
            // if (Array.isArray(newValue)) {
            //     state.statistics = newValue
            // }
            state.statistics = newValue
        },
        setRegionsToRequest(state, newValue) {
            state.regionsToRequest = newValue
        },
        setRegionsFromDistrict(state, districtId) {
            state.regionsFromDistrict = state.statistics.districts[districtId]
        },
    },
    actions: {
        setStatistics(context, newValue) {
            context.commit('setStatistics', newValue)
        },
        setRegionsToRequest(context, newValue) {
            context.commit('setRegionsToRequest', newValue)
        },
        setRegionsFromDistrict(context, districtId) {
            context.commit('setRegionsFromDistrict', districtId)
        },

        dropStatistics(context) {
            context.commit('setStatistics', [])
        },
        async loadStatistics(context) {
            const statistics = await getAllStatistics()
            context.commit('setStatistics', statistics)
        },
        async loadRegions(context) {
            const regionsToRequest = await getAllRegions()
            context.commit('setRegionsToRequest', regionsToRequest)
        },
    },
})

export default store

export { default as SelectRegion } from './SelectRegion.vue'
export { default as StatDistrictCard } from './StatDistrictCard.vue'
export { default as StatAllCard } from './StatAllCard.vue'

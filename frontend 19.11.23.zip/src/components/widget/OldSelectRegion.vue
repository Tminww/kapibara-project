<template>
  <div class="container">
    <input class="search-region" type="text" placeholder="Найти" />
    <div class="container-scroll-region">
      <div class="checkbox-region" v-for="region in regions" :key="region.id">
        <input type="checkbox" id="{{ region.id }}" name="{{ region.id }}" />
        <label for="{{ region.id }}">{{ region.name }}</label>
      </div>
    </div>
    <div class="container-date">
      <div class="select-date">
        <label for="combobox-date">Выбрать интервал дат:</label>

        <select name="combobox-date" id="combobox-date">
          <option disabled>Выберите Период</option>
          <option value="value-1">За прошлый месяц</option>
          <option value="value-2">За прошлый квартал</option>
          <option value="value-3">За прошлый год</option>
        </select>
      </div>

      <div class="output-date">
        <label for="start">Start date:</label>
        <input type="date" id="start" name="start" value="2018-07-22" min="2018-01-01" max="2018-12-31" />
        
        <label for="end">End date:</label>
        <input type="date" id="end" name="end" value="2018-07-22" min="2018-01-01" max="2018-12-31" />
        

      </div>
    </div>
  </div>
</template>

<script lang="js">

export default {
  name: "select-region",
  props: {
    regions: { type: Object, required: true },
  }
};

</script>

<style scoped>
.container {
  display: flex;
  flex-direction: column;

  /* position: fixed;
  top: 0;
  left: 0;
  width: 30%; */

  border: 2px solid pink;

}

.search-region {
  border: 2px solid blue;

}

.container-scroll-region {
  height: 500px;
  overflow-y: scroll;
  border: 2px solid red;
}

.checkbox-region {
  border: 2px solid gray;
  margin: 10px;
}
</style>

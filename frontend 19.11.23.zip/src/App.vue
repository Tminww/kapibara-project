<template>
    <v-app>
        <v-container>


            <v-row>
                <v-col v-if="error">
                    {{ error }}
                </v-col>
                <template v-else>
                    <v-col class="d-flex align-center justify-center" v-if="loading">
                        <v-progress-circular indeterminate></v-progress-circular>
                    </v-col>
                    <template v-else>
                        <v-row>
                            <v-col>
                                <select-region :regions="regions" />
                            </v-col>
                        </v-row>

                        <v-row>
                            <v-col>
                                <template>
                                    <v-treeview :items="regions"></v-treeview>
                                </template>
                            </v-col>
                        </v-row>
                        <v-col>

                            <stat-all-card :all="statistics" />

                        </v-col>
                        <v-col v-for="(district, id) in statistics.districts">
                            <stat-district-card @click="getRegionsByDistrictId(id)" :district="district" />
                        </v-col>
                    </template>
                </template>
            </v-row>

        </v-container>
    </v-app>
</template>

<script lang="js">
import { getAllStatistics, getAllRegions } from './api/statistics.js'
import {
    SelectRegion,
    StatDistrictCard,
    StatAllCard,
} from '@/components/widget'

export default {
    name: 'app',
    components: { StatDistrictCard, SelectRegion, StatAllCard },

    data() {
        return {
            statistics: [],
            regionsInDistrict: [],
            regionsToRequest: [],
            visible: false,
            loading: false,
            error: null,
        }
    },
    computed: {
        /* if data is not updated value bring in cash*/
        getDocumentCount() {
            return this.statistics.count
        },

    },

    methods: {
        async loadStatistics() {
            try {
                this.error = null
                this.loading = true
                this.statistics = await getAllStatistics()
            } catch (e) {
                this.error = e.message
                this.statistics = []
            } finally {
                this.loading = false
            }
        },

        async loadRegions() {
            this.regionsToRequest = await getAllRegions()
        },

        async getRegionsByDistrictId(id) {

            this.regionsInDistrict = [];
            this.regionsInDistrict = this.statistics.districts[id].regions;
            console.log(this.regionsInDistrict);

        }
    },

    async mounted() {
        this.loadRegions();
        this.loadStatistics();
        console.log(this.regionsToRequest);

    },
}
</script>

<style scoped>
.main-container {
    margin-top: 100px;
}
</style>

import Statistics from './statistics'
import Subjects from './subjects'
import Dashboard from './dashboard'
import Parser from './parser'
import Auth from './auth'

const api = {
    statistics: new Statistics('/statistics'),
    subjects: new Subjects('/subjects'),
    dashboard: new Dashboard('/dashboard'),
    parser: new Parser('/parser'),
    auth: new Auth('/auth')
}

export default api

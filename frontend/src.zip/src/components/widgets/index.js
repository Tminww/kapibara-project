export { default as THeaderWidget } from './HeaderWidget.vue'

export { default as TOrganCard } from './TOrganCard.vue'
export { default as TBreadcrumbs } from './TBreadcrumbs.vue'

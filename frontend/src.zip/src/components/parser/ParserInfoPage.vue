<template>
    <v-container>
        <v-row class="justify-space-around">
            <!-- Status Card -->
            <v-col cols="12" md="6">
                <v-card class="d-flex flex-column" style="height: 100%" elevation="3">
                    <v-card-title class="d-flex align-center">
                        <span>Статус процесса сбора данных</span>
                        <v-spacer></v-spacer>
                        <v-chip :color="statusColor" label class="ml-2">
                            {{ status.state }}
                        </v-chip>
                    </v-card-title>

                    <v-card-text class="flex-grow-1">
                        <v-progress-linear
                            v-if="isRunning"
                            :model-value="status.progress"
                            color="primary"
                            height="25"
                            rounded
                            rounded-bar
                        >
                            <template v-slot:default="{ value }">
                                <strong
                                    :style="{
                                        color: Math.ceil(value) > 50 ? 'white' : 'black'
                                    }"
                                    >{{ Math.ceil(value) }}%</strong
                                >
                            </template>
                        </v-progress-linear>

                        <v-alert
                            :color="statusColor"
                            :icon="statusIcon"
                            variant="tonal"
                            class="mt-2"
                            title="Статус выполнения"
                            :text="status.status"
                        >
                        </v-alert>

                        <v-list v-if="status.start_time" density="compact">
                            <v-list-item>
                                <template v-slot:prepend>
                                    <v-icon icon="mdi-clock-start"></v-icon>
                                </template>
                                <v-list-item-title
                                    >Начало: {{ formatDate(status.start_time) }}</v-list-item-title
                                >
                            </v-list-item>

                            <v-list-item v-if="status.end_time">
                                <template v-slot:prepend>
                                    <v-icon icon="mdi-clock-end"></v-icon>
                                </template>
                                <v-list-item-title
                                    >Окончание: {{ formatDate(status.end_time) }}</v-list-item-title
                                >
                            </v-list-item>

                            <v-list-item v-if="status.duration">
                                <template v-slot:prepend>
                                    <v-icon icon="mdi-timer"></v-icon>
                                </template>
                                <v-list-item-title
                                    >Длительность: {{ formatDuration(duration) }}</v-list-item-title
                                >
                            </v-list-item>
                        </v-list>
                    </v-card-text>

                    <v-card-actions class="px-4 py-4">
                        <v-btn
                            :loading="startLoading"
                            color="primary"
                            @click="startParser"
                            :disabled="isRunning"
                            prepend-icon="mdi-play"
                            variant="tonal"
                        >
                            Начать сбор
                        </v-btn>
                        <v-spacer></v-spacer>
                        <v-btn
                            color="error"
                            @click="showStopDialog"
                            :disabled="!isRunning"
                            prepend-icon="mdi-stop"
                            variant="tonal"
                        >
                            Остановить
                        </v-btn>
                    </v-card-actions>
                </v-card>
            </v-col>
            <!-- Performance Chart -->
            <v-col cols="12" md="6" v-if="hasHistoryData">
                <v-card class="h-100" elevation="3">
                    <v-card-title class="d-flex align-center">
                        <span>Длительность</span>
                        <v-spacer></v-spacer>
                        <v-select
                            v-model="historyLimit"
                            :items="[5, 10, 20, 50]"
                            variant="outlined"
                            density="compact"
                            hide-details
                            style="max-width: 120px"
                            @update:model-value="fetchHistory"
                            color="primary"
                        ></v-select>
                    </v-card-title>

                    <v-card-text>
                        <apexchart
                            type="area"
                            height="300"
                            :options="chartOptions"
                            :series="chartSeries"
                        ></apexchart>
                    </v-card-text>
                </v-card>
            </v-col>

            <!-- Stats Cards -->
            <v-col cols="12" md="4" v-if="hasHistoryData">
                <v-card class="h-100" elevation="3">
                    <v-card-text class="text-center">
                        <v-avatar color="success" size="60" class="mb-4" variant="tonal">
                            <v-icon size="32" icon="mdi-check-circle"></v-icon>
                        </v-avatar>
                        <h2 class="mb-2">{{ successfulRuns }}</h2>
                        <p>Успешный сбор данных</p>
                    </v-card-text>
                </v-card>
            </v-col>

            <v-col cols="12" md="4" v-if="hasHistoryData">
                <v-card class="h-100" elevation="3">
                    <v-card-text class="text-center">
                        <v-avatar color="error" size="60" class="mb-4" variant="tonal">
                            <v-icon size="32" icon="mdi-alert-circle"></v-icon>
                        </v-avatar>
                        <h2 class="mb-2">{{ failedRuns }}</h2>
                        <p>Ошибки при выполнении</p>
                    </v-card-text>
                </v-card>
            </v-col>

            <v-col cols="12" md="4" v-if="hasHistoryData">
                <v-card class="h-100" elevation="3">
                    <v-card-text class="text-center">
                        <v-avatar color="info" size="60" class="mb-4" variant="tonal">
                            <v-icon size="32" icon="mdi-clock-outline"></v-icon>
                        </v-avatar>
                        <h2 class="mb-2">{{ avgDuration }}</h2>
                        <p>Среднее время выполнения</p>
                    </v-card-text>
                </v-card>
            </v-col>

            <!-- History Table -->
            <v-col cols="12" :md="hasHistoryData ? 6 : 12">
                <v-card class="h-100" elevation="3">
                    <v-card-title class="d-flex align-center">
                        <span>История запусков</span>
                        <v-spacer></v-spacer>
                        <v-select
                            v-model="historyLimit"
                            :items="[5, 10, 20, 50]"
                            variant="outlined"
                            density="compact"
                            hide-details
                            style="max-width: 120px"
                            @update:model-value="fetchHistory"
                            color="primary"
                        ></v-select>
                    </v-card-title>

                    <v-data-table
                        :headers="historyHeaders"
                        :items="historyTableItems"
                        :loading="loading"
                        items-per-page="15"
                        :items-per-page-options="[15, 20, 50]"
                        fixed-header
                        fixed-footer
                        height="650"
                        density="compact"
                        hover
                    >
                        <template v-slot:item.state="{ item }">
                            <v-chip :color="getStateColor(item.state)" size="small" label>
                                {{ item.state }}
                            </v-chip>
                        </template>

                        <template v-slot:item.duration="{ item }">
                            {{ formatDuration(item.duration) }}
                        </template>

                        <template v-slot:item.start_time="{ item }">
                            {{ formatDate(item.start_time) }}
                        </template>
                        <template v-slot:item.summary="{ item }">
                            {{ item.report.summary.organs_processed || 0 }}
                        </template>
                        <template #item.task_id="{ item }">
                            <v-btn
                                class="text-none ma-1"
                                prepend-icon="mdi-text-box-search"
                                variant="text"
                                @click="showReport(item.task_id)"
                            >
                                Смотреть
                            </v-btn>
                        </template>
                    </v-data-table>
                </v-card>
            </v-col>
            <!-- Last Report -->
            <v-col cols="12" md="6">
                <v-card class="h-100" elevation="3">
                    <v-card-title class="d-flex align-center">
                        <span>Отчет о выполнении</span>
                        <v-spacer></v-spacer>
                        <v-chip :color="lastRunColor" label class="ml-2">
                            {{ lastRun.state }}
                        </v-chip>
                    </v-card-title>
                    <v-card-text class="pb-0">
                        <v-alert
                            :color="lastRunColor"
                            :icon="lastRunIcon"
                            variant="tonal"
                            title="Статус выполнения"
                            :text="lastRun.status"
                        >
                        </v-alert>
                        <!-- Статус выполнения -->

                        <v-row no-gutters>
                            <v-col cols="12" md="6">
                                <v-list density="compact">
                                    <v-list-item>
                                        <template v-slot:prepend>
                                            <v-icon icon="mdi-clock-start"></v-icon>
                                        </template>
                                        <v-list-item-title
                                            >Начало:
                                            {{ formatDate(lastRun.start_time) }}</v-list-item-title
                                        >
                                    </v-list-item>

                                    <v-list-item v-if="lastRun.end_time">
                                        <template v-slot:prepend>
                                            <v-icon icon="mdi-clock-end"></v-icon>
                                        </template>
                                        <v-list-item-title
                                            >Окончание:
                                            {{ formatDate(lastRun.end_time) }}</v-list-item-title
                                        >
                                    </v-list-item>

                                    <v-list-item v-if="lastRun.duration">
                                        <template v-slot:prepend>
                                            <v-icon icon="mdi-timer"></v-icon>
                                        </template>
                                        <v-list-item-title
                                            >Длительность:
                                            {{
                                                formatDuration(lastRun.duration)
                                            }}</v-list-item-title
                                        >
                                    </v-list-item>
                                    <v-list-item v-if="lastRun.report">
                                        <template v-slot:prepend>
                                            <v-icon icon="mdi-map-marker"></v-icon>
                                        </template>
                                        <v-list-item-title
                                            >Обработано источников:
                                            {{ lastRun.report.summary.organs_processed || 0 }} /
                                            {{
                                                lastRun.report.summary.organs_total || 0
                                            }}</v-list-item-title
                                        >
                                    </v-list-item>
                                </v-list>
                            </v-col>

                            <v-col cols="12" md="6">
                                <v-list density="compact">
                                    <v-list-item>
                                        <template v-slot:prepend>
                                            <v-icon icon="mdi-file-document"></v-icon>
                                        </template>
                                        <v-list-item-title
                                            >Обработано документов:
                                            {{ lastRun.report?.summary?.total_documents || 0 }}
                                        </v-list-item-title>
                                    </v-list-item>
                                    <v-list-item>
                                        <template v-slot:prepend>
                                            <v-icon icon="mdi-file-document-check"></v-icon>
                                        </template>
                                        <v-list-item-title
                                            >Успешно:
                                            <v-chip color="success" label>
                                                {{ lastRun.report?.summary?.successful || 0 }}
                                            </v-chip>
                                        </v-list-item-title>
                                    </v-list-item>
                                    <v-list-item>
                                        <template v-slot:prepend>
                                            <v-icon icon="mdi-file-document-remove"></v-icon>
                                        </template>
                                        <v-list-item-title
                                            >Пропущено:
                                            <v-chip color="primary" label>
                                                {{ lastRun.report?.summary?.skipped || 0 }}
                                            </v-chip>
                                        </v-list-item-title>
                                    </v-list-item>
                                    <v-list-item>
                                        <template v-slot:prepend>
                                            <v-icon icon="mdi-file-document-remove"></v-icon>
                                        </template>
                                        <v-list-item-title
                                            >Ошибочно:
                                            <v-chip color="error" label>
                                                {{ lastRun.report?.summary?.failed || 0 }}
                                            </v-chip>
                                        </v-list-item-title>
                                    </v-list-item>
                                </v-list>
                            </v-col>
                        </v-row>

                        <!-- Таблица регионов с результатами -->
                        <v-data-table
                            v-if="lastRun && lastRun.report && lastRun.report.organs"
                            :headers="regionsHeaders"
                            :items="regionsItems"
                            density="compact"
                            fixed-header
                            fixed-footer
                            height="400"
                            v-model:sort-by="sortBy"
                        >
                            <template v-slot:item.success="{ item }">
                                <v-chip color="success" size="small" label v-if="item.success > 0">
                                    {{ item.success }}
                                </v-chip>
                                <span v-else>{{ item.success }}</span>
                            </template>

                            <template v-slot:item.failed="{ item }">
                                <v-chip color="error" size="small" label v-if="item.failed > 0">
                                    {{ item.failed }}
                                </v-chip>
                                <span v-else>{{ item.failed }}</span>
                            </template>

                            <template v-slot:item.processed="{ item }">
                                <v-checkbox-btn
                                    v-model="item.processed"
                                    hide-details
                                    :true-value="true"
                                    :false-value="false"
                                    :disabled="true"
                                ></v-checkbox-btn>
                            </template>
                        </v-data-table>

                        <!-- Сообщение если нет данных -->
                        <v-alert v-if="!lastRun" type="warning" variant="tonal" text class="mt-4">
                            Отчет по сбору данных отсутствует
                        </v-alert>
                    </v-card-text>
                </v-card>
            </v-col>
        </v-row>

        <!-- Stop Confirmation Dialog -->
        <v-dialog v-model="stopDialog" max-width="500">
            <v-card class="px-2 py-2">
                <v-card-title class="text-h5"> Подтвердите остановку </v-card-title>
                <v-card-text>
                    Вы уверены, что хотите <strong>остановить</strong> процесс сбора данных? Это
                    действие необратимо.
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn color="primary" variant="tonal" @click="stopDialog = false">
                        Отменить
                    </v-btn>
                    <v-btn color="error" variant="tonal" @click="confirmStopParser">
                        Остановить
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </v-container>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, watch } from 'vue'
import { useTheme } from 'vuetify'
import api from '@/api'

// State
const theme = useTheme()
const status = ref({
    state: 'UNKNOWN',
    progress: 0,
    status: 'Загружаем информацию о сборе данных...'
})
const history = ref([])
const lastRun = ref({})
const loading = ref(true)
const historyLimit = ref(50)
const stopDialog = ref(false)
const startLoading = ref(false)
const sortBy = [{ key: 'total', order: 'desc' }]
let statusInterval = null

const currentDuration = ref(0)
let durationInterval = null

// Вычисление duration на основе start_time
const duration = computed(() => {
    if (!status.value.start_time) return 0

    // Используем сохраненное значение, если процесс завершен
    if (status.value.end_time) {
        return status.value.duration || 0
    }

    // Иначе возвращаем текущее вычисленное значение
    return currentDuration.value
})

// Функция для обновления значения duration
const updateDuration = () => {
    if (!status.value.start_time) return
    const startTime = new Date(status.value.start_time)
    const currentTime = new Date()
    currentDuration.value = Math.floor((currentTime - startTime) / 1000) // Разница в секундах
}

// Настройка таймера для обновления duration
const setupDurationTimer = () => {
    // Остановить существующий таймер если есть
    if (durationInterval) {
        clearInterval(durationInterval)
    }

    // Запустить новый таймер только если процесс активен
    if (isRunning.value) {
        updateDuration() // Обновить сразу
        durationInterval = setInterval(updateDuration, 1000) // Обновлять каждую секунду
    }
}

function showReport(taskId) {
    // Здесь вы можете реализовать логику для открытия отчета

    lastRun.value = { ...history.value.find((item) => item.task_id === taskId) }
}
// Следить за изменениями статуса для управления таймером
watch(
    () => status.value.state,
    (newState, oldState) => {
        if (newState === 'STARTED' || newState === 'PROGRESS') {
            setupDurationTimer()
        } else if (durationInterval) {
            clearInterval(durationInterval)
        }
    }
)

// Не забудьте очистить таймер при удалении компонента
onUnmounted(() => {
    if (statusInterval) {
        clearInterval(statusInterval)
    }
    if (durationInterval) {
        clearInterval(durationInterval)
    }
})

// History table setup
const historyHeaders = [
    { title: 'Статус', key: 'state', align: 'start', sortable: true },
    { title: 'Дата', key: 'start_time', sortable: true },
    { title: 'Длительность', key: 'duration', sortable: true },
    { title: 'Обработано', key: 'summary', align: 'center', sortable: false },
    { title: 'Отчет', key: 'task_id', align: 'center', sortable: false }
]

// 2. Добавьте реализацию для regionsHeaders и regionsItems (перед компонентом v-data-table)
const regionsHeaders = [
    { title: 'Источник', key: 'name', align: 'start' },
    { title: 'Код', key: 'code', align: 'start' },
    { title: 'Всего', key: 'total', align: 'start' },
    { title: 'Успешно', key: 'success', align: 'start' },
    { title: 'Ошибки', key: 'failed', align: 'start' },
    { title: 'Обработан', key: 'processed', align: 'center' }
]

const regionsItems = computed(() => {
    if (!lastRun.value || !lastRun.value.report || !lastRun.value.report.organs) {
        return []
    }

    return Object.entries(lastRun.value.report.organs).map(([key, data]) => ({
        code: key,
        name: data.name || 'Unknown',
        total: data.total || 0,
        success: data.success || 0,
        failed: data.failed || 0,
        skipped: data.skipped || 0,
        processed: data.processed === true
    }))
})

// Computed properties
const isRunning = computed(() => {
    return status.value.state === 'STARTED' || status.value.state === 'PROGRESS'
})

const statusColor = computed(() => {
    const state = status.value.state
    if (state === 'SUCCESS') return 'success'
    if (state === 'FAILURE' || state === 'REVOKED') return 'error'
    if (state === 'STARTED' || state === 'PROGRESS') return 'primary'
    return 'grey'
})

const statusIcon = computed(() => {
    const state = status.value.state
    if (state === 'SUCCESS') return 'mdi-check-circle'
    if (state === 'FAILURE') return 'mdi-alert-circle'
    if (state === 'REVOKED') return 'mdi-stop-circle'
    if (state === 'STARTED' || state === 'PROGRESS') return 'mdi-progress-clock'
    return 'mdi-information'
})

const lastRunColor = computed(() => {
    const state = lastRun.value.state
    if (state === 'SUCCESS') return 'success'
    if (state === 'FAILURE' || state === 'REVOKED') return 'error'
    if (state === 'STARTED' || state === 'PROGRESS') return 'primary'
    return 'grey'
})
const lastRunIcon = computed(() => {
    const state = lastRun.value.state
    if (state === 'SUCCESS') return 'mdi-check-circle'
    if (state === 'FAILURE') return 'mdi-alert-circle'
    if (state === 'REVOKED') return 'mdi-stop-circle'
    if (state === 'STARTED' || state === 'PROGRESS') return 'mdi-progress-clock'
    return 'mdi-information'
})

// Fixed history table items
const historyTableItems = computed(() => {
    return history.value
})

// Chart data
const hasHistoryData = computed(() => {
    return history.value && history.value.length > 0
})

const chartSeries = computed(() => {
    // Only use entries with duration
    const entriesWithDuration = history.value
        .filter((entry) => entry.duration)
        .slice()
        .reverse()

    return [
        {
            name: 'Длительность',
            data: entriesWithDuration.map((entry) => entry.duration)
        }
    ]
})

const chartOptions = computed(() => {
    const entriesWithDuration = history.value
        .filter((entry) => entry.duration)
        .slice()
        .reverse()

    return {
        chart: {
            type: 'area',
            toolbar: {
                show: false
            },
            zoom: false,
            fontFamily: 'Nunito, sans-serif'
        },
        dataLabels: {
            enabled: false
        },
        stroke: {
            curve: 'smooth',
            width: 3
        },
        fill: {
            type: 'gradient',
            color: ['#'],
            gradient: {
                shadeIntensity: 1,
                opacityFrom: 0.9,
                opacityTo: 0.5
            }
        },
        xaxis: {
            categories: entriesWithDuration.map((_, index) => `Запуск ${index + 1}`),
            labels: {
                // show: entriesWithDuration.length < 20 // Hide labels if too many data points
                show: false
            }
        },
        yaxis: {
            logarithmic: false,
            logBase: 10,
            labels: {
                show: true,
                formatter: function (value) {
                    return formatDuration(value)
                }
            },
            title: {
                show: false
            }
        },
        tooltip: {
            y: {
                formatter: function (value) {
                    return formatDuration(value)
                }
            }
        },
        theme: {
            mode: 'light',
            palette: 'palette1',
            monochrome: {
                enabled: true,
                color: '#1d4c86',
                shadeTo: 'light',
                shadeIntensity: 0.65
            }
        }
    }
})

// Stats cards data
const successfulRuns = computed(() => {
    return history.value.filter((entry) => entry.state === 'SUCCESS').length
})

const failedRuns = computed(() => {
    return history.value.filter((entry) => entry.state === 'FAILURE' || entry.state === 'REVOKED')
        .length
})

const avgDuration = computed(() => {
    const entriesWithDuration = history.value.filter((entry) => entry.duration)
    if (entriesWithDuration.length === 0) return '0 сек'

    const totalDuration = entriesWithDuration.reduce((sum, entry) => sum + entry.duration, 0)
    const avg = totalDuration / entriesWithDuration.length

    return formatDuration(avg)
})

// Methods
const getStateColor = (state) => {
    if (state === 'SUCCESS') return 'success'
    if (state === 'FAILURE' || state === 'REVOKED') return 'error'
    if (state === 'STARTED' || state === 'PROGRESS') return 'primary'
    return 'grey'
}

const fetchStatus = async () => {
    try {
        const response = await api.parser.status()
        status.value = response

        // Перезапустить таймер duration при получении нового статуса
        if (isRunning.value) {
            setupDurationTimer()
        }
    } catch (error) {
        console.error('Error fetching parser status:', error)
    } finally {
        loading.value = false
    }
}

const fetchHistory = async () => {
    try {
        loading.value = true
        const response = await api.parser.history({ limit: historyLimit.value })
        history.value = response.history || []

        // Если есть история и еще нет последнего отчета, используем самую свежую запись
        if (history.value.length > 0 && !lastRun.value) {
            fetchLastRun()
        }
    } catch (error) {
        console.error('Error fetching parser history:', error)
    } finally {
        loading.value = false
    }
}

const fetchLastRun = async () => {
    try {
        const response = await api.parser.lastRun()

        lastRun.value = response
    } catch (error) {
        // Если получили ошибку 404, попробуем использовать последнюю запись из истории
        if (error.response && error.response.status === 404 && history.value.length > 0) {
            // Сортируем историю по времени начала (в убывающем порядке) и берем первую запись
            const sortedHistory = [...history.value].sort(
                (a, b) => new Date(b.start_time) - new Date(a.start_time)
            )
            if (sortedHistory[0] && sortedHistory[0].summary) {
                lastRun.value = {
                    summary: sortedHistory[0].summary, // Добавляем объект summary отдельно
                    timestamp: sortedHistory[0].end_time,
                    task_id: sortedHistory[0].task_id
                }
            }
        } else if (error.response && error.response.status !== 404) {
            console.error('Error fetching last report:', error)
        }
    }
}

const startParser = async () => {
    try {
        startLoading.value = true
        await api.parser.start()
        await new Promise((resolve) => setTimeout(resolve, 2000)) // Delay for 2 seconds

        await fetchStatus()
        await fetchHistory()
    } catch (error) {
        console.error('Error starting parser:', error)
    } finally {
        startLoading.value = false
    }
}

const showStopDialog = () => {
    stopDialog.value = true
}

const confirmStopParser = async () => {
    stopDialog.value = false

    try {
        await api.parser.stop()
        await fetchStatus()
        await fetchHistory()
    } catch (error) {
        console.error('Error stopping parser:', error)
    }
}

const formatDate = (dateString) => {
    if (!dateString) return '-'
    const date = new Date(dateString)
    const pad = (num) => String(num).padStart(2, '0')
    return `${pad(date.getDate())}.${pad(date.getMonth() + 1)}.${date.getFullYear()} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`
}

const formatDuration = (seconds) => {
    if (!seconds && seconds !== 0) return '-'

    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const remainingSeconds = Math.floor(seconds % 60)

    if (hours > 0) {
        return `${hours} ч ${minutes} мин ${remainingSeconds} сек`
    }
    if (minutes > 0) {
        return `${minutes} мин ${remainingSeconds} сек`
    }
    return `${remainingSeconds} сек`
}

const copyReportToClipboard = () => {
    if (!lastRun.value) return

    const reportText = JSON.stringify(lastRun.value, null, 2)
    navigator.clipboard.writeText(reportText).then(() => {
        // Could use Vuetify snackbar here for feedback
    })
}

function openReportInLastRun(taskId) {}
const setupStatusPolling = () => {
    // Poll status every 3 seconds
    statusInterval = setInterval(async () => {
        if (isRunning.value) {
            await fetchStatus()
        }
    }, 3000)
}

// Watch for theme changes to update chart
watch(
    () => theme.current.value.dark,
    () => {
        // Force chart to re-render when theme changes
        if (hasHistoryData.value) {
            // This just updates the chart options which will re-render the chart
        }
    }
)

// Lifecycle hooks
onMounted(async () => {
    await fetchStatus()
    await fetchHistory()
    await fetchLastRun()
    setupStatusPolling()
})

onUnmounted(() => {
    if (statusInterval) {
        clearInterval(statusInterval)
    }
})
</script>

<style scoped></style>

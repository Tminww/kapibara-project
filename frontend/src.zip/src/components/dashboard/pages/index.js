export { default as DashboardPage } from './DashboardPage.vue'
export { default as DistrictPage } from './DistrictPage.vue'
export { default as RegionPage } from './RegionPage.vue'

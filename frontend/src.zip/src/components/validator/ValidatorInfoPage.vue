<template>
    <v-container>
        <v-row class="justify-space-around">
            <!-- Status Card -->
            <v-col cols="12" md="6">
                <v-card class="d-flex flex-column" style="height: 100%" elevation="3">
                    <v-card-title class="d-flex align-center">
                        <span>Статус процесса валидации</span>
                        <v-spacer></v-spacer>
                        <v-chip :color="statusColor" label class="ml-2">
                            {{ status.state }}
                        </v-chip>
                    </v-card-title>

                    <v-card-text class="flex-grow-1">
                        <v-progress-linear
                            v-if="isRunning"
                            :model-value="status.progress"
                            color="primary"
                            height="25"
                            rounded
                            rounded-bar
                        >
                            <template v-slot:default="{ value }">
                                <strong>{{ Math.ceil(value) }}%</strong>
                            </template>
                        </v-progress-linear>

                        <v-alert
                            :color="statusColor"
                            :icon="statusIcon"
                            variant="tonal"
                            class="mt-2"
                            title="Статус выполнения"
                            :text="status.status"
                        >
                        </v-alert>

                        <v-list v-if="status.start_time" density="compact">
                            <v-list-item>
                                <template v-slot:prepend>
                                    <v-icon icon="mdi-clock-start"></v-icon>
                                </template>
                                <v-list-item-title
                                    >Начало: {{ formatDate(status.start_time) }}</v-list-item-title
                                >
                            </v-list-item>

                            <v-list-item v-if="status.end_time">
                                <template v-slot:prepend>
                                    <v-icon icon="mdi-clock-end"></v-icon>
                                </template>
                                <v-list-item-title
                                    >Окончание: {{ formatDate(status.end_time) }}</v-list-item-title
                                >
                            </v-list-item>

                            <v-list-item v-if="status.duration">
                                <template v-slot:prepend>
                                    <v-icon icon="mdi-timer"></v-icon>
                                </template>
                                <v-list-item-title
                                    >Длительность: {{ formatDuration(duration) }}</v-list-item-title
                                >
                            </v-list-item>
                        </v-list>
                    </v-card-text>

                    <v-card-actions class="px-4 py-4">
                        <v-btn
                            color="primary"
                            @click="showStartDialog"
                            :disabled="isRunning"
                            prepend-icon="mdi-play"
                            variant="tonal"
                        >
                            Начать валидацию
                        </v-btn>
                        <v-spacer></v-spacer>
                        <v-btn
                            color="error"
                            @click="showStopDialog"
                            :disabled="!isRunning"
                            prepend-icon="mdi-stop"
                            variant="tonal"
                        >
                            Остановить
                        </v-btn>
                    </v-card-actions>
                </v-card>
            </v-col>
            <!-- Performance Chart -->
            <v-col cols="12" md="6" v-if="hasHistoryData">
                <v-card class="h-100" elevation="3">
                    <v-card-title class="d-flex align-center">
                        <span>Длительность</span>
                        <v-spacer></v-spacer>
                        <v-select
                            v-model="historyLimit"
                            :items="[5, 10, 20, 50]"
                            variant="outlined"
                            density="compact"
                            hide-details
                            style="max-width: 120px"
                            @update:model-value="fetchHistory"
                            color="primary"
                        ></v-select>
                    </v-card-title>

                    <v-card-text>
                        <apexchart
                            type="area"
                            height="300"
                            :options="chartOptions"
                            :series="chartSeries"
                        ></apexchart>
                    </v-card-text>
                </v-card>
            </v-col>

            <!-- Stats Cards -->
            <v-col cols="12" md="4" v-if="hasHistoryData">
                <v-card class="h-100" elevation="3">
                    <v-card-text class="text-center">
                        <v-avatar color="success" size="60" class="mb-4" variant="tonal">
                            <v-icon size="32" icon="mdi-check-circle"></v-icon>
                        </v-avatar>
                        <h2 class="mb-2">{{ successfulRuns }}</h2>
                        <p>Успешная валидация</p>
                    </v-card-text>
                </v-card>
            </v-col>

            <v-col cols="12" md="4" v-if="hasHistoryData">
                <v-card class="h-100" elevation="3">
                    <v-card-text class="text-center">
                        <v-avatar color="error" size="60" class="mb-4" variant="tonal">
                            <v-icon size="32" icon="mdi-alert-circle"></v-icon>
                        </v-avatar>
                        <h2 class="mb-2">{{ failedRuns }}</h2>
                        <p>Ошибки при выполнении</p>
                    </v-card-text>
                </v-card>
            </v-col>

            <v-col cols="12" md="4" v-if="hasHistoryData">
                <v-card class="h-100" elevation="3">
                    <v-card-text class="text-center">
                        <v-avatar color="info" size="60" class="mb-4" variant="tonal">
                            <v-icon size="32" icon="mdi-clock-outline"></v-icon>
                        </v-avatar>
                        <h2 class="mb-2">{{ avgDuration }}</h2>
                        <p>Среднее время выполнения</p>
                    </v-card-text>
                </v-card>
            </v-col>

            <!-- History Table -->
            <v-col cols="12" :md="hasHistoryData ? 6 : 12">
                <v-card class="h-100" elevation="3">
                    <v-card-title class="d-flex align-center">
                        <span>История запусков</span>
                        <v-spacer></v-spacer>
                        <v-select
                            v-model="historyLimit"
                            :items="[5, 10, 20, 50]"
                            variant="outlined"
                            density="compact"
                            hide-details
                            style="max-width: 120px"
                            @update:model-value="fetchHistory"
                            color="primary"
                        ></v-select>
                    </v-card-title>

                    <v-data-table
                        :headers="historyHeaders"
                        :items="historyTableItems"
                        :loading="loading"
                        items-per-page="15"
                        :items-per-page-options="[15, 20, 50]"
                        fixed-header
                        fixed-footer
                        height="650"
                        density="compact"
                        hover
                    >
                        <template v-slot:item.state="{ item }">
                            <v-chip :color="getStateColor(item.state)" size="small" label>
                                {{ item.state }}
                            </v-chip>
                        </template>

                        <template v-slot:item.duration="{ item }">
                            {{ formatDuration(item.duration) }}
                        </template>

                        <template v-slot:item.start_time="{ item }">
                            {{ formatDate(item.start_time) }}
                        </template>
                        <template v-slot:item.summary="{ item }">
                            {{ item.results?.total_documents || 0 }}
                        </template>
                        <template #item.task_id="{ item }">
                            <v-btn
                                class="text-none ma-1"
                                prepend-icon="mdi-text-box-search"
                                variant="text"
                                @click="showReport(item.task_id)"
                            >
                                Смотреть
                            </v-btn>
                        </template>
                    </v-data-table>
                </v-card>
            </v-col>
            <!-- Last Report -->
            <v-col cols="12" md="6">
                <v-card class="h-100" elevation="3">
                    <v-card-title class="d-flex align-center">
                        <span>Отчет о выполнении</span>
                        <v-spacer></v-spacer>
                        <v-chip :color="lastRunColor" label class="ml-2" v-if="lastRun.state">
                            {{ lastRun.state }}
                        </v-chip>
                    </v-card-title>
                    <v-card-text class="pb-0">
                        <v-alert
                            v-if="lastRun.state"
                            :color="lastRunColor"
                            :icon="lastRunIcon"
                            variant="tonal"
                            title="Статус выполнения"
                            :text="lastRun.status"
                        >
                        </v-alert>
                        <!-- Статус выполнения -->

                        <v-row no-gutters v-if="lastRun.start_time">
                            <v-col cols="12" md="6">
                                <v-list density="compact">
                                    <v-list-item>
                                        <template v-slot:prepend>
                                            <v-icon icon="mdi-clock-start"></v-icon>
                                        </template>
                                        <v-list-item-title
                                            >Начало:
                                            {{ formatDate(lastRun.start_time) }}</v-list-item-title
                                        >
                                    </v-list-item>

                                    <v-list-item v-if="lastRun.end_time">
                                        <template v-slot:prepend>
                                            <v-icon icon="mdi-clock-end"></v-icon>
                                        </template>
                                        <v-list-item-title
                                            >Окончание:
                                            {{ formatDate(lastRun.end_time) }}</v-list-item-title
                                        >
                                    </v-list-item>

                                    <v-list-item v-if="lastRun.duration">
                                        <template v-slot:prepend>
                                            <v-icon icon="mdi-timer"></v-icon>
                                        </template>
                                        <v-list-item-title
                                            >Длительность:
                                            {{
                                                formatDuration(lastRun.duration)
                                            }}</v-list-item-title
                                        >
                                    </v-list-item>
                                    <v-list-item v-if="lastRun.params">
                                        <template v-slot:prepend>
                                            <v-icon icon="mdi-calendar-range"></v-icon>
                                        </template>
                                        <v-list-item-title
                                            >Период:
                                            {{ formatDateShort(lastRun.params.start_date) }} -
                                            {{
                                                formatDateShort(lastRun.params.end_date)
                                            }}</v-list-item-title
                                        >
                                    </v-list-item>
                                </v-list>
                            </v-col>

                            <v-col cols="12" md="6">
                                <v-list density="compact" v-if="lastRun.results">
                                    <v-list-item>
                                        <template v-slot:prepend>
                                            <v-icon icon="mdi-file-document"></v-icon>
                                        </template>
                                        <v-list-item-title
                                            >Всего документов:
                                            {{ lastRun.results.total || 0 }}
                                        </v-list-item-title>
                                    </v-list-item>
                                    <v-list-item>
                                        <template v-slot:prepend>
                                            <v-icon icon="mdi-file-document-check"></v-icon>
                                        </template>
                                        <v-list-item-title
                                            >Успешно:
                                            <v-chip color="success" label>
                                                {{ lastRun.results.successful || 0 }}
                                            </v-chip>
                                        </v-list-item-title>
                                    </v-list-item>
                                    <v-list-item>
                                        <template v-slot:prepend>
                                            <v-icon icon="mdi-file-document-remove"></v-icon>
                                        </template>
                                        <v-list-item-title
                                            >Ошибки:
                                            <v-chip color="error" label>
                                                {{ lastRun.results.failed || 0 }}
                                            </v-chip>
                                        </v-list-item-title>
                                    </v-list-item>
                                    <v-list-item>
                                        <template v-slot:prepend>
                                            <v-icon icon="mdi-check-circle-outline"></v-icon>
                                        </template>
                                        <v-list-item-title
                                            >Прошли валидацию:
                                            <v-chip color="success" label>
                                                {{ lastRun.results.validation_passed || 0 }}
                                            </v-chip>
                                        </v-list-item-title>
                                    </v-list-item>
                                </v-list>
                            </v-col>
                        </v-row>

                        <!-- Таблица с результатами валидации -->
                        <v-data-table
                            v-if="lastRun && lastRun.results && lastRun.results.details"
                            :headers="detailsHeaders"
                            :items="detailsItems"
                            density="compact"
                            fixed-header
                            fixed-footer
                            height="400"
                            v-model:sort-by="sortBy"
                        >
                            <template v-slot:item.similarity="{ item }">
                                <v-chip
                                    :color="getSimilarityColor(item.similarity)"
                                    size="small"
                                    label
                                >
                                    {{ (item.similarity * 100).toFixed(1) }}%
                                </v-chip>
                            </template>
                            <template v-slot:item.validation_passed="{ item }">
                                <v-icon v-if="item.validation_passed" color="success"
                                    >mdi-check</v-icon
                                >
                                <v-icon v-else color="error">mdi-close</v-icon>
                            </template>
                        </v-data-table>

                        <!-- Сообщение если нет данных -->
                        <v-alert
                            v-if="!lastRun.state"
                            type="warning"
                            variant="tonal"
                            text
                            class="mt-4"
                        >
                            Отчет по валидации данных отсутствует
                        </v-alert>
                    </v-card-text>
                </v-card>
            </v-col>
        </v-row>

        <v-dialog v-model="startDialog" max-width="600">
            <v-card class="px-2 py-2">
                <v-card-title class="text-h5">Параметры валидации</v-card-title>
                <v-card-text>
                    <v-form ref="validationForm" v-model="isFormValid">
                        <v-row>
                            <v-col cols="12" md="6">
                                <v-text-field
                                    v-model="validationParams.start_date"
                                    label="Начальная дата"
                                    type="date"
                                    required
                                    :rules="dateRules"
                                ></v-text-field>
                            </v-col>
                            <v-col cols="12" md="6">
                                <v-text-field
                                    v-model="validationParams.end_date"
                                    label="Конечная дата"
                                    type="date"
                                    required
                                    :rules="dateRules"
                                ></v-text-field>
                            </v-col>
                        </v-row>
                        <v-autocomplete
                            v-model="validationParams.district_ids"
                            :items="districtItems"
                            item-title="name"
                            item-value="id"
                            label="Округа"
                            multiple
                            chips
                            clearable
                        ></v-autocomplete>
                        <v-autocomplete
                            v-model="validationParams.authority_ids"
                            :items="authorityItems"
                            item-title="name"
                            item-value="id"
                            label="Органы власти"
                            multiple
                            chips
                            clearable
                        ></v-autocomplete>
                    </v-form>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn color="primary" variant="tonal" @click="startDialog = false">
                        Отменить
                    </v-btn>
                    <v-btn
                        color="success"
                        variant="tonal"
                        @click="startValidation"
                        :disabled="!isFormValid || startLoading"
                        :loading="startLoading"
                    >
                        Начать валидацию
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>

        <!-- Stop Confirmation Dialog -->
        <v-dialog v-model="stopDialog" max-width="500">
            <v-card class="px-2 py-2">
                <v-card-title class="text-h5"> Подтвердите остановку </v-card-title>
                <v-card-text>
                    Вы уверены, что хотите <strong>остановить</strong> процесс валидации данных? Это
                    действие необратимо.
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn color="primary" variant="tonal" @click="stopDialog = false">
                        Отменить
                    </v-btn>
                    <v-btn color="error" variant="tonal" @click="confirmStopValidation">
                        Остановить
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </v-container>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, watch } from 'vue'
import { useTheme } from 'vuetify'
import api from '@/api'

// State
const theme = useTheme()
const status = ref({
    state: 'UNKNOWN',
    progress: 0,
    status: 'Загружаем информацию о валидации данных...',
    task_id: null
})
const history = ref([])
const lastRun = ref({})
const loading = ref(true)
const historyLimit = ref(50)
const stopDialog = ref(false)
const startDialog = ref(false)
const startLoading = ref(false)
const isFormValid = ref(false)
const sortBy = [{ key: 'similarity', order: 'desc' }]
let statusInterval = null

// Параметры валидации
const validationParams = ref({
    start_date: new Date().toISOString().split('T')[0],
    end_date: new Date().toISOString().split('T')[0],
    district_ids: [],
    authority_ids: []
})

// Правила валидации формы
const dateRules = [
    (v) => !!v || 'Дата обязательна',
    (v) => /^\d{4}-\d{2}-\d{2}$/.test(v) || 'Неверный формат даты'
]

// Заглушки для списков - в реальном приложении нужно заполнить из API
const districtItems = ref([
    { id: 1, name: 'Центральный' },
    { id: 2, name: 'Северо-Западный' },
    { id: 3, name: 'Южный' },
    { id: 4, name: 'Северо-Кавказский' },
    { id: 5, name: 'Приволжский' },
    { id: 6, name: 'Уральский' },
    { id: 7, name: 'Сибирский' },
    { id: 8, name: 'Дальневосточный' }
])

const authorityItems = ref([
    { id: '001', name: 'Министерство внутренних дел' },
    { id: '002', name: 'Министерство образования' },
    { id: '003', name: 'Министерство здравоохранения' },
    { id: '004', name: 'Федеральная налоговая служба' },
    { id: '005', name: 'Министерство транспорта' }
])

const currentDuration = ref(0)
let durationInterval = null

// Вычисление duration на основе start_time
const duration = computed(() => {
    if (!status.value.start_time) return 0

    // Используем сохраненное значение, если процесс завершен
    if (status.value.end_time) {
        return status.value.duration || 0
    }

    // Иначе возвращаем текущее вычисленное значение
    return currentDuration.value
})

// Функция для обновления значения duration
const updateDuration = () => {
    if (!status.value.start_time) return
    const startTime = new Date(status.value.start_time)
    const currentTime = new Date()
    currentDuration.value = Math.floor((currentTime - startTime) / 1000) // Разница в секундах
}

// Настройка таймера для обновления duration
const setupDurationTimer = () => {
    // Остановить существующий таймер если есть
    if (durationInterval) {
        clearInterval(durationInterval)
    }

    // Запустить новый таймер только если процесс активен
    if (isRunning.value) {
        updateDuration() // Обновить сразу
        durationInterval = setInterval(updateDuration, 1000) // Обновлять каждую секунду
    }
}

function showReport(taskId) {
    // Загрузка отчета по task_id
    fetchReport(taskId)
}

// Следить за изменениями статуса для управления таймером
watch(
    () => status.value.state,
    (newState, oldState) => {
        if (newState === 'STARTED' || newState === 'PROGRESS') {
            setupDurationTimer()
        } else if (durationInterval) {
            clearInterval(durationInterval)
        }
    }
)

// Не забудьте очистить таймер при удалении компонента
onUnmounted(() => {
    if (statusInterval) {
        clearInterval(statusInterval)
    }
    if (durationInterval) {
        clearInterval(durationInterval)
    }
})

// History table setup
const historyHeaders = [
    { title: 'Статус', key: 'state', align: 'start', sortable: true },
    { title: 'Дата', key: 'start_time', sortable: true },
    { title: 'Длительность', key: 'duration', sortable: true },
    { title: 'Документов', key: 'summary', align: 'center', sortable: false },
    { title: 'Отчет', key: 'task_id', align: 'center', sortable: false }
]

// Заголовки для таблицы деталей
const detailsHeaders = [
    { title: 'ID', key: 'doc_id', align: 'start' },
    { title: 'Название документа', key: 'document_title', align: 'start' },
    { title: 'Сходство', key: 'similarity', align: 'center' },
    { title: 'Проверено', key: 'validation_passed', align: 'center' }
]

// Элементы таблицы деталей
const detailsItems = computed(() => {
    if (!lastRun.value || !lastRun.value.results || !lastRun.value.results.details) {
        return []
    }

    return lastRun.value.results.details.map((item) => ({
        doc_id: item.document_id || '-',
        document_title: item.title || 'Без названия',
        similarity: item.similarity || 0,
        validation_passed: item.validation_passed || false
    }))
})

// Получение цвета по значению сходства
const getSimilarityColor = (similarity) => {
    if (similarity >= 0.9) return 'success'
    if (similarity >= 0.7) return 'warning'
    return 'error'
}

// Computed properties
const isRunning = computed(() => {
    return status.value.state === 'STARTED' || status.value.state === 'PROGRESS'
})

const statusColor = computed(() => {
    const state = status.value.state
    if (state === 'SUCCESS') return 'success'
    if (state === 'FAILURE' || state === 'REVOKED') return 'error'
    if (state === 'STARTED' || state === 'PROGRESS') return 'primary'
    return 'grey'
})

const statusIcon = computed(() => {
    const state = status.value.state
    if (state === 'SUCCESS') return 'mdi-check-circle'
    if (state === 'FAILURE') return 'mdi-alert-circle'
    if (state === 'REVOKED') return 'mdi-stop-circle'
    if (state === 'STARTED' || state === 'PROGRESS') return 'mdi-progress-clock'
    return 'mdi-information'
})

const lastRunColor = computed(() => {
    const state = lastRun.value.state
    if (state === 'SUCCESS') return 'success'
    if (state === 'FAILURE' || state === 'REVOKED') return 'error'
    if (state === 'STARTED' || state === 'PROGRESS') return 'primary'
    return 'grey'
})

const lastRunIcon = computed(() => {
    const state = lastRun.value.state
    if (state === 'SUCCESS') return 'mdi-check-circle'
    if (state === 'FAILURE') return 'mdi-alert-circle'
    if (state === 'REVOKED') return 'mdi-stop-circle'
    if (state === 'STARTED' || state === 'PROGRESS') return 'mdi-progress-clock'
    return 'mdi-information'
})

// Fixed history table items
const historyTableItems = computed(() => {
    return history.value
})

// Chart data
const hasHistoryData = computed(() => {
    return history.value && history.value.length > 0
})

const chartSeries = computed(() => {
    // Only use entries with duration
    const entriesWithDuration = history.value
        .filter((entry) => entry.duration)
        .slice()
        .reverse()

    return [
        {
            name: 'Длительность',
            data: entriesWithDuration.map((entry) => entry.duration)
        }
    ]
})

const chartOptions = computed(() => {
    const entriesWithDuration = history.value
        .filter((entry) => entry.duration)
        .slice()
        .reverse()

    return {
        chart: {
            type: 'area',
            toolbar: {
                show: false
            },
            zoom: false,
            fontFamily: 'Nunito, sans-serif'
        },
        dataLabels: {
            enabled: false
        },
        stroke: {
            curve: 'smooth',
            width: 3
        },
        fill: {
            type: 'gradient',
            gradient: {
                shadeIntensity: 1,
                opacityFrom: 0.9,
                opacityTo: 0.5
            }
        },
        xaxis: {
            categories: entriesWithDuration.map((_, index) => `Запуск ${index + 1}`),
            labels: {
                show: false
            }
        },
        yaxis: {
            logarithmic: true,
            logBase: 10,
            labels: {
                show: true,
                formatter: function (value) {
                    return formatDuration(value)
                }
            },
            title: {
                show: false
            }
        },
        tooltip: {
            y: {
                formatter: function (value) {
                    return formatDuration(value)
                }
            }
        },
        theme: {
            mode: 'light',
            palette: 'palette1',
            monochrome: {
                enabled: true,
                color: '#1d4c86',
                shadeTo: 'light',
                shadeIntensity: 0.65
            }
        }
    }
})

// ...continuing from where it left off
const successfulRuns = computed(() => {
    return history.value.filter((run) => run.state === 'SUCCESS').length
})

const failedRuns = computed(() => {
    return history.value.filter((run) => run.state === 'FAILURE' || run.state === 'REVOKED').length
})

const avgDuration = computed(() => {
    const completedRuns = history.value.filter((run) => run.duration)
    if (!completedRuns.length) return '0с'

    const totalDuration = completedRuns.reduce((sum, run) => sum + run.duration, 0)
    return formatDuration(Math.floor(totalDuration / completedRuns.length))
})

// Helper functions
const formatDate = (dateString) => {
    if (!dateString) return '-'
    const date = new Date(dateString)
    return date.toLocaleString('ru-RU', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    })
}

const formatDateShort = (dateString) => {
    if (!dateString) return '-'
    const date = new Date(dateString)
    return date.toLocaleDateString('ru-RU', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    })
}

const formatDuration = (seconds) => {
    if (!seconds) return '0с'

    const hrs = Math.floor(seconds / 3600)
    const mins = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60

    let result = ''
    if (hrs > 0) result += `${hrs}ч `
    if (mins > 0) result += `${mins}м `
    if (secs > 0 || result === '') result += `${secs}с`

    return result.trim()
}

const getStateColor = (state) => {
    if (state === 'SUCCESS') return 'success'
    if (state === 'FAILURE' || state === 'REVOKED') return 'error'
    if (state === 'STARTED' || state === 'PROGRESS') return 'primary'
    return 'grey'
}

// API Interaction
const fetchStatus = async () => {
    try {
        // Если есть ID задачи в localStorage, то запрашиваем её статус
        const taskId = localStorage.getItem('current_validation_task')
        if (taskId) {
            const response = await api.get(`/validator/status/${taskId}`)
            status.value = {
                ...response.data,
                start_time: response.data.start_time || null,
                end_time: response.data.end_time || null,
                duration: response.data.duration || 0
            }

            // Если задача завершена, обновляем историю
            if (
                response.data.state === 'SUCCESS' ||
                response.data.state === 'FAILURE' ||
                response.data.state === 'REVOKED'
            ) {
                fetchHistory()
                fetchReport(taskId)
            }
        }
    } catch (error) {
        console.error('Error fetching validation status:', error)
    }
}

const fetchHistory = async () => {
    try {
        loading.value = true
        const response = await api.get(`/validator/history?limit=${historyLimit.value}`)
        history.value = response.data.map((item) => ({
            ...item,
            start_time: item.start_time || null,
            end_time: item.end_time || null,
            duration: item.duration || 0
        }))

        // Если есть история, берем последний элемент для отображения
        if (history.value.length > 0) {
            const lastTaskId = history.value[0].task_id
            if (lastTaskId) {
                fetchReport(lastTaskId)
            }
        }
    } catch (error) {
        console.error('Error fetching validation history:', error)
    } finally {
        loading.value = false
    }
}

const fetchReport = async (taskId) => {
    try {
        const response = await api.get(`/validator/report/${taskId}`)
        lastRun.value = {
            ...response.data,
            state: response.data.state || 'UNKNOWN',
            start_time: response.data.start_time || null,
            end_time: response.data.end_time || null,
            duration: response.data.duration || 0,
            status: response.data.status || 'Нет данных',
            params: response.data.parameters || {},
            results: response.data.summary
                ? {
                      total: response.data.summary.total_documents || 0,
                      successful: response.data.summary.processed_successfully || 0,
                      failed: response.data.summary.failed_to_process || 0,
                      validation_passed: response.data.summary.validation_passed || 0,
                      details: response.data.details || []
                  }
                : null
        }
    } catch (error) {
        console.error('Error fetching validation report:', error)
    }
}

// Action methods
const showStartDialog = () => {
    // Установка текущих дат по умолчанию
    const today = new Date()
    const startDate = new Date()
    startDate.setDate(today.getDate() - 7) // Неделя назад

    validationParams.value = {
        start_date: startDate.toISOString().split('T')[0],
        end_date: today.toISOString().split('T')[0],
        district_ids: [],
        authority_ids: []
    }

    startDialog.value = true
}

const showStopDialog = () => {
    stopDialog.value = true
}

const startValidation = async () => {
    try {
        startLoading.value = true

        const response = await api.post('/validator/documents', validationParams.value)

        // Сохраняем ID задачи в localStorage
        if (response.data.task_id) {
            localStorage.setItem('current_validation_task', response.data.task_id)
        }

        // Сразу запрашиваем статус новой задачи
        await fetchStatus()

        startDialog.value = false
    } catch (error) {
        console.error('Error starting validation:', error)
    } finally {
        startLoading.value = false
    }
}

const confirmStopValidation = async () => {
    try {
        const taskId = status.value.task_id
        if (taskId) {
            await api.post(`/validator/stop/${taskId}`)
            stopDialog.value = false

            // Запрашиваем статус для обновления информации
            await fetchStatus()
        }
    } catch (error) {
        console.error('Error stopping validation:', error)
    }
}

// Lifecycle hooks
onMounted(async () => {
    // Первоначальная загрузка данных
    await fetchStatus()
    await fetchHistory()

    // Настройка интервала для обновления статуса
    statusInterval = setInterval(fetchStatus, 5000)
})

onUnmounted(() => {
    // Очистка интервалов при уничтожении компонента
    if (statusInterval) {
        clearInterval(statusInterval)
    }

    if (durationInterval) {
        clearInterval(durationInterval)
    }
})
</script>

from api.subjects import router as router_subjects
from api.statistics import router as router_statistics


all_routers = [
    router_subjects,
    router_statistics,
]

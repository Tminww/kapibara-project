from abc import ABC, abstractmethod
from datetime import datetime

from sqlalchemy import insert, select, func
from schemas.statistic import StatRowSchema, RequestBodySchema
from schemas.region import RegionSchema
from database.setup import async_session_maker
from errors import ResultIsEmptyError


class AbstractRepository(ABC):
    @abstractmethod
    async def find_all():
        raise NotImplementedError

    @abstractmethod
    async def get_stat_in_regions(parameters):
        raise NotImplementedError


class SQLAlchemyRepository(AbstractRepository):
    model = None
    document = None
    region = None
    act = None

    async def find_all(self):
        async with async_session_maker() as session:
            stmt = select(self.model)
            res = await session.execute(stmt)

            # res = [RegionSchema(id=row.id, name=row.name, code=row.code, checked=False) for row in res.all()]
            res = [row[0].to_read_model() for row in res.all()]

            print(res)
            if res:
                return res
            else:
                raise ResultIsEmptyError("Result is empty")

    async def get_stat_in_regions(self, parameters: RequestBodySchema):
        async with async_session_maker() as session:
            current_date = datetime.now().strftime("%Y-%m-%d")
            current_date = datetime.strptime(current_date, "%Y-%m-%d")

            if parameters.start_date is None and parameters.end_date is None:
                start_date = None
                end_date = None
            elif parameters.start_date is None and parameters.end_date is not None:
                start_date = datetime.strptime(parameters.end_date, "%Y-%m-%d")
                end_date = datetime.strptime(parameters.end_date, "%Y-%m-%d")
            elif parameters.start_date is not None and parameters.end_date is None:
                start_date = datetime.strptime(parameters.start_date, "%Y-%m-%d")
                end_date = current_date
            elif parameters.start_date is not None and parameters.end_date is not None:
                start_date = datetime.strptime(parameters.start_date, "%Y-%m-%d")
                end_date = datetime.strptime(parameters.end_date, "%Y-%m-%d")
            
            stmt = (
                select(
                    self.region.name.label("region_name"),
                    self.act.name.label("act_name"),
                    func.count().label("count"),
                )
                .select_from(self.document)
                .join(self.region, self.document.id_reg == self.region.id)
                .join(self.act, self.document.id_act == self.act.id)
                .filter(
                    (
                        parameters.regions is None
                        or self.region.id.in_(parameters.regions)
                    ),
                    (
                        parameters.start_date is None
                        and parameters.end_date is None
                        or self.document.view_date.between(
                            start_date, end_date
                        )
                    )
                )
                .group_by(self.region.name, self.act.name)
                .order_by(self.region.name)
            )
            res = await session.execute(stmt)
            res = [
                StatRowSchema(
                    region_name=row.region_name, act_name=row.act_name, count=row.count
                )
                for row in res.all()
            ]

            print(res)
            if res:
                return res
            else:
                raise ResultIsEmptyError("Result is empty")

            

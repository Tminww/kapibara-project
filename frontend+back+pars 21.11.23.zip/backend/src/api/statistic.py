from typing import Annotated, Union, Optional, List

from fastapi import APIRouter, Depends, Query, HTTPException
from pydantic import ValidationError
from api.dependencies import document_service
from schemas.statistic import RequestBodySchema
from services.document import DocumentService
from errors import DateValidationError, ResultIsEmptyError

router = APIRouter(
    prefix="/statistics",
    tags=["Statistic in regions"],
)


@router.get("")
async def get_documents_in_regions(
    statistics_service: Annotated[DocumentService, Depends(document_service)],
    regions: Union[List[int], None] = Query(None),
    start_date: Union[str, None] = None,
    end_date: Union[str, None] = None,
):
    try:
        parameters = RequestBodySchema(
            regions=regions, start_date=start_date, end_date=end_date
        )
        
    except ValueError as e:
        raise DateValidationError(e)
    else:
        documents = await statistics_service.get_stat_in_regions(parameters)
        return documents


@router.get("/{region_id}")
async def get_documents_in_one_region(
    statistics_service: Annotated[DocumentService, Depends(document_service)],
    region_id: int,
):
    print(region_id)
    try:
        parameters = RequestBodySchema(
            regions=[region_id]
        )
        
    except ValueError as e:
        raise DateValidationError(e)
    else:
        documents = await statistics_service.get_stat_in_regions(parameters)
        return documents

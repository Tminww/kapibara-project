from api.region import router as router_region
from api.statistic import router as router_statistic


all_routers = [
    router_region,
    router_statistic,
]

from repositories.statistic import StatisticRepository,RegionRepository
from services.document import DocumentService


def document_service():
    return DocumentService(StatisticRepository)

def region_service():
    return DocumentService(RegionRepository)



from typing import Annotated

from fastapi import APIRouter, Depends

from api.dependencies import document_service, region_service
from schemas.region import RegionSchema
from services.document import DocumentService

router = APIRouter(
    prefix="/regions",
    tags=["Regions"],
)


@router.get("")
async def get_documents(
    regions_service: Annotated[DocumentService, Depends(region_service)],
):
    regions = await regions_service.get_regions()
    return regions

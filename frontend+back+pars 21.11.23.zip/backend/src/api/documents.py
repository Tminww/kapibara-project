from typing import Annotated

from fastapi import APIRouter, Depends

from api.dependencies import documents_service
from schemas.documents import DocumentSchema
from services.documents import DocumentsService

router = APIRouter(
    prefix="/documents",
    tags=["Documents"],
)


@router.get("")
async def get_documents(
    documents_service: Annotated[DocumentsService, Depends(documents_service)],
):
    documents = await documents_service.get_documents()
    return documents

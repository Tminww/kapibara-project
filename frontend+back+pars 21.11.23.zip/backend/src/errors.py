class DateValidationError(ValueError):
    pass

class ResultIsEmptyError(ValueError):
    pass
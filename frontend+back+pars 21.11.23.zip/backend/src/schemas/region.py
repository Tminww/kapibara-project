from pydantic import BaseModel


class RegionSchema(BaseModel):
    id: int
    name: str
    code: str
    checked: bool

    class Config:
        # from_attributes = True
        validate_assignment = True



from datetime import date, datetime
from pydantic import BaseModel, validator
from typing import Optional
from errors import DateValidationError


class ActSchema(BaseModel):
    id_act: int
    name: str
    npaId: str

    class Config:
        # from_attributes = True
        validate_assignment = True


class DocumentSchema(BaseModel):
    id_doc: int
    id_act: int
    complexName: str
    eoNumber: int
    viewDate: date
    pagesCount: int
    id_reg: int

    class Config:
        from_attributes = True
        validate_assignment = True


class StatRowSchema(BaseModel):
    region_name: str
    act_name: str
    count: int

    class Config:
        from_attributes = True
        validate_assignment = True


# создать дто для возвращения на сайт


class StatRegionSchema(BaseModel):
    region_name: str
    count: int
    stat: Optional[list] = None

    class Config:
        from_attributes = True
        validate_assignment = True


class StatRegionsSchema(BaseModel):
    count: int
    regions: Optional[list[StatRegionSchema]] = None

    class Config:
        from_attributes = True
        validate_assignment = True


class RequestBodySchema(BaseModel):
    regions: Optional[list[int]] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None

    @validator("start_date")
    def start_date_validator(cls, value):
        if value is not None:
            try:
                datetime.strptime(value, "%Y-%m-%d")
                return value
            except ValueError:
                raise ValueError(value)
        else:
            return value

    @validator("end_date")
    def end_date_validator(cls, value):
        if value is not None:
            try:
                datetime.strptime(value, "%Y-%m-%d")
                return value
            except ValueError:
                raise ValueError(value)
        else:
            return value

    class Config:
        from_attributes = True
        validate_assignment = True

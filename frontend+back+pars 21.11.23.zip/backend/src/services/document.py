from schemas.statistic import StatRegionSchema, StatRegionsSchema
from utils.repository import AbstractRepository


class DocumentService:
    def __init__(self, documents_repo: AbstractRepository):
        self.documents_repo: AbstractRepository = documents_repo()

    # async def add_task(self, task: TaskSchemaAdd):
    #     tasks_dict = task.model_dump()
    #     task_id = await self.tasks_repo.add_one(tasks_dict)
    #     return task_id

    async def get_regions(self):
        regions = await self.documents_repo.find_all()
        return regions

    async def get_stat_in_regions(self, parameters):
        db_response = await self.documents_repo.get_stat_in_regions(parameters)
        stat_in_regions: list = []
        stat_list: list = []
        all_count_of_documents: int = 0
        count_of_documents: int = 0
        prev_region_name: str = db_response[0].region_name

        for row_count, stat in enumerate(db_response, start=1):
            print(row_count)
            if prev_region_name == stat.region_name:
                count_of_documents += stat.count
                all_count_of_documents += stat.count
                stat_list.append({"name": stat.act_name, "count": stat.count})

                if row_count == len(db_response):
                    """this is necessary if region is last"""

                    stat_in_regions.append(
                        StatRegionSchema(
                            region_name=prev_region_name,
                            stat=stat_list,
                            count=count_of_documents,
                        )
                    )

            else:
                """this is necessary if region changed"""

                stat_in_regions.append(
                    StatRegionSchema(
                        region_name=prev_region_name,
                        stat=stat_list,
                        count=count_of_documents,
                    )
                )
                stat_list.clear()
                count_of_documents = 0

                count_of_documents += stat.count
                all_count_of_documents += stat.count
                prev_region_name = stat.region_name

                stat_list.append({"name": stat.act_name, "count": stat.count})

                if row_count == len(db_response):
                    """this is necessary if region is last"""

                    stat_in_regions.append(
                        StatRegionSchema(
                            region_name=prev_region_name,
                            stat=stat_list,
                            count=count_of_documents,
                        )
                    )

        return StatRegionsSchema(count=all_count_of_documents, regions=stat_in_regions)

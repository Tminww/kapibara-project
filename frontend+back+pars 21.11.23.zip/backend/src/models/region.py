from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy import String, UniqueConstraint
from database.setup import Base
from schemas.region import RegionSchema


class RegionEntity(Base):
    __tablename__ = "region"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(128))
    code: Mapped[str] = mapped_column(String(16))

    # documents = relationship("DocumentEntity", innerjoin=True)

    __table_args__ = (
        UniqueConstraint("name", "code"),
        {"extend_existing": True},
    )

    def to_read_model(self) -> RegionSchema:
        return RegionSchema(
            id=self.id,
            name=self.name,
            code=self.code,
            checked=False,
        )
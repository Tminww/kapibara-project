from models.document import DocumentEntity
from models.act import ActEntity
from models.region import RegionEntity
from utils.repository import SQLAlchemyRepository


class StatisticRepository(SQLAlchemyRepository):
    document = DocumentEntity
    region = RegionEntity
    act = ActEntity

class RegionRepository(SQLAlchemyRepository):
    model = RegionEntity
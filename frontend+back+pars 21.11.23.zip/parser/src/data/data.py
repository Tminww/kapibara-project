import psycopg2 
from psycopg2.errorcodes import UNIQUE_VIOLATION
from psycopg2 import errors
from config import get_settings
from datetime import datetime
import logging

logging.basicConfig(
    level=logging.INFO,
    filename="./log/API-Parser.log",
    filemode="w",
    format="%(asctime)s %(levelname)s %(message)s",
)

settings = get_settings()

try:
    connection = psycopg2.connect(
        user=settings.DB_USER,
        password=settings.DB_PASS,
        host=settings.DB_HOST,
        port=settings.DB_PORT,
        database=settings.DB_NAME,
    )
    connection.autocommit = True
except:
    logging.critical("Connect to DB is fail. write 'docker-compose up -d'")

def disconnect():
    connection.close()


CREATE_REGION_TABLE = """
        CREATE TABLE IF NOT EXISTS region (
        id SERIAL NOT NULL, 
        name VARCHAR(128) NOT NULL, 
        code VARCHAR(16) NOT NULL, 
        PRIMARY KEY (id), 
        UNIQUE (name, code)
        )
        """

CREATE_ACT_TABLE = """
        CREATE TABLE IF NOT EXISTS act (
        id SERIAL NOT NULL, 
        name VARCHAR(128) NOT NULL, 
        npa_id VARCHAR(128) NOT NULL, 
        PRIMARY KEY (id), 
        UNIQUE (name, npa_id)
        )
        """

CREATE_DOCUMENT_TABLE = """
        CREATE TABLE IF NOT EXISTS document (
        id BIGSERIAL NOT NULL, 
        complex_name TEXT NOT NULL, 
        id_act INTEGER NOT NULL, 
        eo_number VARCHAR(16) NOT NULL, 
        view_date DATE NOT NULL, 
        pages_count INTEGER NOT NULL, 
        id_reg INTEGER NOT NULL, 
        PRIMARY KEY (id), 
        UNIQUE (id_reg, complex_name, eo_number), 
        FOREIGN KEY(id_act) REFERENCES act (id), 
        FOREIGN KEY(id_reg) REFERENCES region (id)
        )
        """

INSERT_ACT = """INSERT INTO ACT (name, npa_id) VALUES """

INSERT_REGION = """INSERT INTO REGION (name, code) VALUES """

INSERT_DOCUMENT = """INSERT INTO DOCUMENT (complex_name, id_act, eo_number, view_date, pages_count, id_reg) VALUES """


def create_tables():
    create_region_table()
    create_act_table()
    create_document_table()
    logging.info("Таблицы созданы или уже существуют")


def create_region_table():
    with connection:
        with connection.cursor() as cursor:
            cursor.execute(CREATE_REGION_TABLE)


def create_act_table():
    with connection:
        with connection.cursor() as cursor:
            cursor.execute(CREATE_ACT_TABLE)


def create_document_table():
    with connection:
        with connection.cursor() as cursor:
            cursor.execute(CREATE_DOCUMENT_TABLE)


def insert_act(name_npaId):
    with connection:
        with connection.cursor() as cursor:
            try:
                values = name_npaId
                args = ",".join(
                    cursor.mogrify("(%s, %s)", i).decode("utf-8") for i in values
                )
                cursor.execute(INSERT_ACT + args + " ON CONFLICT DO NOTHING;")
            except errors.lookup(UNIQUE_VIOLATION) as e:
                logging.exception(UNIQUE_VIOLATION)


def insert_region(name_code):
    with connection:
        with connection.cursor() as cursor:
            try:
                values = name_code
                args = ",".join(
                    cursor.mogrify("(%s, %s)", i).decode("utf-8") for i in values
                )
                cursor.execute(INSERT_REGION + args + " ON CONFLICT DO NOTHING;")
            except errors.lookup(UNIQUE_VIOLATION) as e:
                logging.exception(UNIQUE_VIOLATION)


def get_id_reg(code):
    with connection:
        with connection.cursor() as cursor:
            cursor.execute(f"""SELECT id from region WHERE code = '{code}';""")
            id_reg = cursor.fetchone()[0]
            return id_reg


def get_id_act(npa_id):
    with connection:
        with connection.cursor() as cursor:
            cursor.execute(f"""SELECT id FROM ACT WHERE npa_id = '{npa_id}';""")
            id_act = cursor.fetchone()[0]
            return id_act


def insert_document(complex_names, eo_numbers, pages_counts, view_dates, id_regs, id_acts):
    with connection:
        with connection.cursor() as cursor:
            values = list(
                zip(complex_names, id_acts, eo_numbers, view_dates, pages_counts, id_regs)
            )
            args = ",".join(
                cursor.mogrify("(%s, %s, %s, %s, %s, %s)", i).decode("utf-8")
                for i in values
            )
            try:
                cursor.execute(INSERT_DOCUMENT + args + " ON CONFLICT DO NOTHING;")
            except errors.lookup(UNIQUE_VIOLATION) as e:
                logging.exception(UNIQUE_VIOLATION)


def get_total_documents(code):
    with connection:
        with connection.cursor() as cursor:
            try:
                cursor.execute(f"""SELECT id from region WHERE code = '{code}';""")
                id_reg = cursor.fetchone()[0]

                cursor.execute(
                    f"""SELECT COUNT(*) FROM DOCUMENT WHERE 
                               id_reg = {id_reg};"""
                )
                count = cursor.fetchone()[0]
                return count
            except Exception as e:
                logging.exception(Exception)


def get_total_documents_type(code, npa_id):
    with connection:
        with connection.cursor() as cursor:
            try:
                cursor.execute(f"""SELECT id FROM ACT WHERE npa_id = '{npa_id}';""")
                id_act = cursor.fetchone()[0]

                cursor.execute(f"""SELECT id from region WHERE code = '{code}';""")
                id_reg = cursor.fetchone()[0]

                cursor.execute(
                    f"""SELECT COUNT(*) FROM DOCUMENT WHERE 
                               id_reg = {id_reg} and id_act = {id_act};"""
                )
                count = cursor.fetchone()[0]
                return count
            except Exception as e:
                logging.exception(Exception)

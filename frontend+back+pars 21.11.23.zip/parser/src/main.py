import requests
import time
from datetime import datetime
from data.data import (
    get_total_documents,
    get_total_documents_type,
    create_tables,
    insert_act,
    insert_document,
    insert_region,
    get_id_reg,
    get_id_act,
)
import logging

#   Добавить обертку для обрашения к апи с количеством попыток и задержек

logging.basicConfig(
    level=logging.INFO,
    filename="log/API-Parser.log",
    filemode="a",
    format="%(asctime)s %(levelname)s %(message)s",
)


API_DOCUMENTS_ON_PAGE = (
    "http://publication.pravo.gov.ru/api/Documents?block={code}&PageSize=200&Index=1"
)
API_DOCUMENTS_ON_PAGE_TYPE = (
    "http://publication.pravo.gov.ru/api/Documents?DocumentTypes={npa_id}&block={"
    "code}&PageSize=200&Index={index}"
)
API_SUBJECTS = "http://publication.pravo.gov.ru/api/PublicBlocks/?parent=subjects"
API_TYPE_ALL = "http://publication.pravo.gov.ru/api/DocumentTypes"
API_TYPE_IN_SUBJECT = "http://publication.pravo.gov.ru/api/DocumentTypes?block={code}"


def check_time(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        res = func(*args, **kwargs)
        end_time = time.time()
        logging.info(f"{func.__name__} Всего времени {end_time - start_time}")
        return res

    return wrapper


@check_time
def get_document_api(code):
    logging.info(f"Регион {code} начат")

    req_total_documents = requests.get(
        url=API_DOCUMENTS_ON_PAGE.replace("{code}", code),
    )

    if get_total_documents(code=code) == req_total_documents.json()["itemsTotalCount"]:
        logging.info(f"Регион {code} уже заполнен")
        return

    req_type = requests.get(
        url=API_TYPE_IN_SUBJECT.replace("{code}", code),
    )
    for npa in req_type.json():
        current_page = 1
        while True:
            time.sleep(0.5)
            req = requests.get(
                url=API_DOCUMENTS_ON_PAGE_TYPE.replace("{code}", code)
                .replace("{index}", str(current_page))
                .replace("{npa_id}", npa["id"])
            )
            if (
                get_total_documents_type(code=code, npa_id=npa["id"])
                == req.json()["itemsTotalCount"]
            ):
                break

            if current_page <= req.json()["pagesTotalCount"]:
                complex_names: list = []
                eo_numbers: list = []
                pages_counts: list = []
                view_dates: list = []
                id_regs: list = []
                id_acts: list = []
                id_reg = get_id_reg(code=code)
                id_act = get_id_act(npa_id=npa["id"])

                for item in req.json()["items"]:
                    complex_names.append(item["complexName"])
                    eo_numbers.append(item["eoNumber"])
                    pages_counts.append(item["pagesCount"])
                    view_dates.append(
                        datetime.strptime(item["viewDate"], "%d.%m.%Y").strftime(
                            "%Y-%m-%d"
                        )
                    )
                    id_regs.append(id_reg)
                    id_acts.append(id_act)
                insert_document(
                    complex_names, eo_numbers, pages_counts, view_dates, id_regs, id_acts
                )
                current_page += 1

            elif (
                current_page > req.json()["pagesTotalCount"]
                or req.json()["pagesTotalCount"] == 0
            ):
                break
    logging.info(f"Регион {code} закончен")


def get_npa_api() -> list:
    names: list = []
    npa_id: list = []
    req = requests.get(url=API_TYPE_ALL)

    for npa in req.json():
        names.append(npa["name"])
        npa_id.append(npa["id"])
    return list(zip(names, npa_id))


def get_subject_api() -> list:
    req = requests.get(url=API_SUBJECTS)
    names: list = []
    codes: list = []
    for subject in req.json():
        names.append(subject["name"])
        codes.append(subject["code"])
    return list(zip(names, codes))


def main():
    create_tables()

    name_code = get_subject_api()
    name_npa_id = get_npa_api()

    insert_act(name_npa_id)
    insert_region(name_code)

    for name, code in name_code:
        get_document_api(code=code)

    logging.info("Заполнение завершено!")


if __name__ == "__main__":
    main()

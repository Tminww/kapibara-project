<template>
    <v-app>
        <v-container>

            <v-row>
                <v-col v-if="error">
                    {{ error }}
                </v-col>
                <v-col class="d-flex align-center justify-center" v-if="loading">
                    <v-progress-circular indeterminate></v-progress-circular>
                </v-col>
            </v-row>

            <template v-if="!loading && !error">
                <!-- <v-row>
                    <v-col>
                        <select-region :regions="getRegionsToRequest" />
                    </v-col>
                </v-row> -->
                <v-row>

                    <v-col>
                        <stat-all-card :all="this.getStatistics" />
                    </v-col>
                </v-row>
                <v-row>
                    <v-col v-for="(district, id) in this.getDistricts">
                        <stat-district-card @click="regionsFromDistricStore(id)" :district="district" />
                    </v-col>
                </v-row>
            </template>

        </v-container>
    </v-app>
</template>

<script lang="js">
import {
    SelectRegion,
    StatDistrictCard,
    StatAllCard,
} from '@/components/widget'
import { mapGetters, mapActions } from 'vuex'

export default {
    name: 'app',
    components: { StatDistrictCard, SelectRegion, StatAllCard },

    data() {
        return {
            visible: false,
            loading: false,
            error: null,
        }
    },
    computed: {
        ...mapGetters(['getStatistics', 'getRegionsToRequest', 'getRegionsFromDistrict', 'getDistricts']),
        /* if data is not updated value bring in cash*/

    },

    methods: {
        ...mapActions(['dropStatistics', 'loadRegions', 'loadStatistics', 'setRegionsFromDistrict']),
        async loadStatisticsStore() {
            try {
                this.error = null
                this.loading = true
                this.loadStatistics()
            } catch (e) {
                this.error = e.message
                this.dropStatistics()
            } finally {
                this.loading = false
            }
        },

        async loadRegionsStore() {
            this.loadRegions()
            // this.regionsToRequest = await getAllRegions()
        },

        async regionsFromDistricStore(id) {
            this.setRegionsFromDistrict(id);
            console.log(this.getRegionsInDistrict)
        },
    },

    async mounted() {
        await this.loadRegionsStore()
        await this.loadStatisticsStore()
    },
}
</script>

<style scoped>
.main-container {
    margin-top: 100px;
}
</style>

<template>
    <v-card class="rounded-xl mx-auto" elevation="0" variant="tonal" width="400">
        <v-card-title class="text-h6 mb-1">
            {{ name }}
        </v-card-title>

        <v-card-subtitle class="text-subtitle-2">
            {{ count }}
        </v-card-subtitle>

        <v-img src="./src/assets/pie.jpg" height="200px"> </v-img>

        <v-card-text primary-title> </v-card-text>

        <!-- <v-card-actions>
            <v-btn color="indigo" @click="onClicked">
                <template v-if="visible == true"> Закрыть Статистику </template>
                <template v-else> Открыть статистику </template>
            </v-btn>
        </v-card-actions> -->

        <!-- <v-card-text v-show="visible">
            <template v-for="region in regions">
                <v-row>
                    <stat-region-card :region="region">
                    </stat-region-card>
                </v-row>
            </template>
        </v-card-text> -->
    </v-card>
</template>

<script lang="js">
import StatRegionCard from './StatRegionCard.vue'
import StatBase from "./StatBase.vue"

export default {
    name: 'stat-district-card',

    components: { StatRegionCard, StatBase },
    props: {

        district: { type: Object, required: true },
    },
    data() {
        return {
            visible: false,
            name: this.district.name,
            count: this.district.count,
            regions: this.district.regions
        }
    },
}
</script>
<style scoped></style>

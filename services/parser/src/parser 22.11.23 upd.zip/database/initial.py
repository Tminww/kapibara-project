from database.setup import get_sync_connection
from psycopg2.errorcodes import UNIQUE_VIOLATION
from psycopg2 import errors
from log.createLogger import Logger

logging = Logger("./log/initialDataBase.log", "a").get_logger()

CREATE_REGION_TABLE = """
        CREATE TABLE IF NOT EXISTS region (
        id SERIAL NOT NULL, 
        id_dist INTEGER, 
        name VARCHAR(128) NOT NULL, 
        code VARCHAR(16) NOT NULL, 
        PRIMARY KEY (id), 
        UNIQUE (name, code),
        FOREIGN KEY(id_dist) REFERENCES district (id)
        )
        """

CREATE_ACT_TABLE = """
        CREATE TABLE IF NOT EXISTS act (
        id SERIAL NOT NULL, 
        name VARCHAR(128) NOT NULL, 
        npa_id VARCHAR(128) NOT NULL, 
        PRIMARY KEY (id), 
        UNIQUE (name, npa_id)
        )
        """

CREATE_DOCUMENT_TABLE = """
        CREATE TABLE IF NOT EXISTS document (
        id BIGSERIAL NOT NULL, 
        complex_name TEXT NOT NULL, 
        id_act INTEGER NOT NULL, 
        eo_number VARCHAR(16) NOT NULL, 
        view_date DATE NOT NULL, 
        pages_count INTEGER NOT NULL, 
        id_reg INTEGER NOT NULL, 
        PRIMARY KEY (id), 
        UNIQUE (id_reg, complex_name, eo_number), 
        FOREIGN KEY(id_act) REFERENCES act (id), 
        FOREIGN KEY(id_reg) REFERENCES region (id)
        )
        """

CREATE_DISTRICT_TABLE = """
        CREATE TABLE IF NOT EXISTS district (
        id INT PRIMARY KEY,
        name VARCHAR(50)
        )
        """

INSERT_DISTRICTS = """
        INSERT INTO district (id, name) 
        VALUES
        (1, 'Центральный'),
        (2, 'Северо-Западный'),
        (3, 'Южный'),
        (4, 'Северо-Кавказский'),
        (5, 'Приволжский'),
        (6, 'Уральский'),
        (7, 'Сибирский'),
        (8, 'Дальневосточный')
        ON CONFLICT DO NOTHING;
        """


def create_tables():
    create_district_table()
    insert_district_table()
    create_region_table()
    create_act_table()
    create_document_table()

    logging.info("Таблицы созданы или уже существуют")


def create_district_table():
    with get_sync_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(CREATE_DISTRICT_TABLE)


def insert_district_table():
    with get_sync_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(INSERT_DISTRICTS)


def create_region_table():
    with get_sync_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(CREATE_REGION_TABLE)


def create_act_table():
    with get_sync_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(CREATE_ACT_TABLE)


def create_document_table():
    with get_sync_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(CREATE_DOCUMENT_TABLE)

import logging


class Logger:
    # создаем регистратор

    def __init__(self, file_name, mode) -> None:
        self.logger = logging.getLogger("logger")
        self.logger.setLevel(logging.INFO)
        # создаем обработчик для файла и
        # установим уровень отладки
        self.ch = logging.FileHandler(file_name, mode)
        self.ch.setLevel(logging.INFO)

        # строка формата сообщения
        self.strfmt = "[%(asctime)s] [%(name)s] [%(levelname)s] > %(message)s"
        # строка формата времени
        self.datefmt = "%Y-%m-%d %H:%M:%S"
        # создаем форматтер
        self.formatter = logging.Formatter(fmt=self.strfmt, datefmt=self.datefmt)

        # добавляем форматтер к 'ch'
        self.ch.setFormatter(self.formatter)
        # добавляем ch в регистратор
        self.logger.addHandler(self.ch)
        # вызов функций, регистрирующих
        # события в коде

    def get_logger(self):
        return self.logger

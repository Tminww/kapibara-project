<template>
    <v-app>
        <v-app-bar :elevation="2" />
        <v-container class="main-container">
            <v-row>
                <v-col>
                    <select-region :regions="regions" />
                </v-col>
            </v-row>
            <v-row>
                <!-- <v-col>
                    <stat-card :key="statistics.name" :stat="statistics.stat" />
                </v-col> -->


            </v-row>

            <v-row>
                <v-col v-if="error">
                    {{ error }}
                </v-col>
                <template v-else>
                    <v-col v-if="loading">Loading...</v-col>
                    <template v-else>
                        <v-col v-for="stat in statistics.districts">
                            <stat-district-card :key="stat.name" :stat="stat" />
                        </v-col>
                    </template>
                </template>
            </v-row>
            <div></div>
        </v-container>
    </v-app>
</template>

<script lang="js">

// import { ref } from 'vue'

// const variants = ['elevated', 'flat', 'tonal', 'outlined']
// const color = ref('indigo')

import { getAllStatistics, getAllRegions } from "./api/statistics.js";
import { SelectRegion, StatDistrictCard } from "@/components/widget";

export default {
    name: "app",
    components: { StatDistrictCard, SelectRegion },

    data() {
        return {
            statistics: [],
            regions: [],
            loading: false,
            error: null
        };
    },
    computed: {
        /* if data is not updated value bring in cash*/
        getDocumentCount() {
            return this.statistics.count;
        }
    },

    methods: {
        async loadStatistics() {
            try {
                this.error = null;
                this.loading = true;
                this.statistics = await getAllStatistics();
            } catch (e) {
                this.error = e.message;
                this.statistics = [];
            } finally {
                this.loading = false;
            }
        },

        async loadRegions() {
            this.regions = await getAllRegions();
        }
    },

    async mounted() {
        this.loadRegions();
        console.log();
        this.loadStatistics();
    }
};
</script>

<style scoped>
.main-container {
    margin-top: 100px;
}
</style>

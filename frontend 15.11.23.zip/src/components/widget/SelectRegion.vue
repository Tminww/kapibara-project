<template>
    <v-autocomplete label="Регионы" :items="regions" multiple item-title="name" item-value="id"
        return-object></v-autocomplete>
</template>

<script lang="js">
export default {
    name: "select-region",
    props: {
        regions: { type: Object, required: true }
    },
    mounted() {
        console.log(this.regions);
    }
};
</script>

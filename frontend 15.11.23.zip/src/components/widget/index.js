export { default as SelectRegion } from './SelectRegion.vue'
export { default as StatDistrictCard } from './StatDistrictCard.vue'

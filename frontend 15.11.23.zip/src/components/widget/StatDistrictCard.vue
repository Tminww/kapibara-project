<template>
    <v-card width="400" :title="stat.name" :subtitle="stat.count">
        <!-- <v-card-text>
            <div class="npa-statistics" v-for="districtStat in stat.stat">
                <div class="npa-name">{{ districtStat.name }}:</div>
                <div class="npa-count">{{ districtStat.count }}</div>
            </div>
        </v-card-text>
        <v-card-actions>
            <v-btn dark>
                Открыть статистику
            </v-btn>
        </v-card-actions> -->

        <v-img src="./images/pie.jpg" height="200px">
        </v-img>

        <v-card-text primary-title>

        </v-card-text>

        <v-card-actions>
            <v-btn color="indigo" @click="visible = !visible">
                <template v-if="visible == true">
                    Закрыть Статистику
                </template>
                <template v-else>
                    Открыть статистику
                </template>

            </v-btn>
        </v-card-actions>

        <v-slide-y-transition>
            <v-card-text v-show="visible">
                <div class="npa-statistics" v-for="districtStat in stat.stat">
                    <div class="npa-name">{{ districtStat.name }}:</div>
                    <div class="npa-count">{{ districtStat.count }}</div>
                </div>
            </v-card-text>
        </v-slide-y-transition>
    </v-card>
</template>
<script>
export default {
    name: "stat-card",
    props: {
        stat: { type: Object, required: true }
    },
    data() {
        return {
            visible: false,
        }
    },
    methods: {
        showContent: function (event) {
            // `this` внутри методов указывает на экземпляр Vue
            alert('Привет, ' + '!')
            // `event` — нативное событие DOM

        },
    }
};
</script>
<style scoped>
.row {
    display: flex;
    margin-bottom: 5px;
    border: 1px solid gray;
    border-radius: 15px;
    justify-content: flex-start;
}

.title {
    margin-bottom: 5px;
    margin-top: 5px;
    margin-left: 10px;
    padding-left: 10px;
    padding-right: 10px;
    border-right: 1px solid gray;
    margin-right: 20px;
    flex-basis: 100px;
}

.npa-statistics {
    margin-bottom: 5px;
    align-items: center;
    /*border: 1px solid gold;*/

    display: flex;
}

.statistics {
    /*border: 1px solid green;*/
    margin-bottom: 5px;
    margin-top: 5px;
}

districtStat-count-document {
    /*border: 1px solid blue;*/
}

districtStat-name {
    font-weight: 700;
    /*border: 1px solid red;*/
}

.npa-name {
    font-weight: 700;
    margin-right: 5px;
}

.npa-count {}
</style>
